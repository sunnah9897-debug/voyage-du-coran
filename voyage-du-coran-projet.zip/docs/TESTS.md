# Plan de tests — version 0.4.0

Date : 24 octobre 2026.

## A. Tests exécutés automatiquement par Claude

Exécutés dans Chromium 141 (sans écran), taille téléphone 360 × 740 et 320 × 568, sur un serveur local.
Ces tests ne remplacent pas un essai sur un vrai téléphone Android.

| N° | Action | Résultat attendu | Résultat obtenu | Statut |
| --- | --- | --- | --- | --- |
| 1a | Premier lancement | Choix Enfant / Adulte proposé | Proposé | Réussi |
| 1 | Ouvrir l'application | L'accueil s'affiche | Accueil affiché | Réussi |
| 2 | Aller dans Alphabet, ouvrir une fiche | 28 lettres ; fiche avec 4 formes | 28 lettres, fiche de bâ' avec 4 formes | Réussi |
| 3 | Afficher les lettres arabes | Première lettre : ا | ا | Réussi |
| 4 | Sens de lecture | alif placé à droite de bâ' | Grille en droite-gauche | Réussi |
| 5 | Répondre faux puis juste aux 15 exercices | Faux = rouge + bonne réponse en vert ; 15 exercices à 100 % | 0/4 en faux ; 66/66 en juste | Réussi |
| 6 | Calcul des points | 66 × 10 = 660 ; rejouer ne change rien | 660, inchangé après rejeu | Réussi |
| 7 | Recharger la page | Points et badges conservés | 660 points, 15/15, 5 badges | Réussi |
| 8 | Effacer la progression depuis Paramètres (avec confirmation) | Retour à 0 | 0 point | Réussi |
| 9 | Écran de 320 px, 8 écrans | Aucun défilement horizontal | Aucun débordement | Réussi |
| 10 | Répondre au clavier (Tab + Entrée) | La réponse est prise en compte | Correction affichée | Réussi |
| 11 | Couper le réseau puis recharger | Accueil, exercice et fiche s'ouvrent | Ouverts sans réseau | Réussi |
| 12 | Fermer et rouvrir (rechargement) | Progression conservée | Voir test 7 | Réussi |
| 13 | Adresse inconnue ; progression abîmée | Page « introuvable » ; jeu qui redémarre à 0 | Conforme | Réussi |
| — | Polices intégrées chargées (arabe, texte, titres) | Les 3 polices actives | Les 3 actives | Réussi |
| — | Paramètres conservés après rechargement | Thème sombre et grand texte gardés | Conforme | Réussi |
| J1 | Jeu « Quelle image ? », 8 bonnes réponses | 8/8 | 8/8 | Réussi |
| J2 | Jeu de mémoire, 6 paires en 6 coups | 12 cartes trouvées, 3 étoiles | Conforme | Réussi |
| J3 | Jeu « Épeler », 6 mots justes | 6/6 | 6/6 | Réussi |
| J4 | Tracer : gribouillis à côté de la lettre | Refusé | Refusé | Réussi |
| J5 | Tracer : tracé qui suit la lettre (5 lettres ; mesure séparée sur les 28) | Accepté | 5/5, et 28/28 en mesure séparée | Réussi |
| J6 | Badge « Explorateur » après les 4 jeux | Obtenu | Obtenu | Réussi |
| K1 | Mode Enfant activé | Jamal affiché, couleurs vives | Conforme | Réussi |
| K2 | Fiche de lettre : mot illustré et écoute | جَمَل 🐪 et 2 boutons d'écoute | Conforme | Réussi |
| K3 | Mode Enfant et jeux à 320 px (9 écrans) | Aucun débordement | Aucun | Réussi |
| A1 | Application Android simulée : écouter un mot | Lu par la synthèse vocale Android | بَطَّة envoyé au pont | Réussi |
| A2 | Application Android simulée : service worker | Aucun | Aucun | Réussi |
| A3 | Application Android simulée : Paramètres › Installer la voix arabe | Ouvre le réglage | Appel reçu | Réussi |
| A4 | Application Android simulée : voix arabe absente | Message clair | Message affiché | Réussi |
| A5 | Code Java de l'application compilé contre des modèles des bibliothèques Android | Aucune erreur | Aucune erreur | Réussi (vérification partielle) |
| — | Erreurs JavaScript pendant tous les tests | Aucune | Aucune | Réussi |
| — | Tests de logique et de contenu (28 tests Node.js) | Tous réussis | 28/28 | Réussi |

Résultat : 39/39 tests navigateur et 28/28 tests de logique réussis.

La compilation réelle de l'APK n'a pas pu être faite ici : les serveurs Google nécessaires sont inaccessibles depuis l'environnement de Claude. Elle se fait sur GitHub ; son résultat est à vérifier dans l'onglet Actions.

## B. Tests que tu dois faire toi-même

| N° | Action | Résultat attendu | Statut |
| --- | --- | --- | --- |
| B1 | Ouvrir le jeu sur ton téléphone Android dans Chrome | Texte lisible, lettres arabes bien formées | À faire |
| B2 | Jouer les 15 exercices sur le téléphone | Aucun bouton difficile à toucher | À faire |
| B2b | Activer le son et la vibration dans Paramètres, puis se tromper volontairement | Un son et une courte vibration | À faire (impossible à vérifier sans vrai téléphone) |
| B2c | Toucher un bouton haut-parleur sur la fiche de بَاء | La voix du téléphone lit le mot ; sinon, un message explique comment installer la voix arabe | À faire (impossible à vérifier ici : pas de voix dans l'environnement de test) |
| B2d | Jeu « Tracer » avec le doigt sur 5 lettres | Accepté quand on suit la lettre, refusé quand on gribouille | À faire (le test automatique utilise une souris) |
| B2e | Faire jouer 3 enfants en mode Enfant | Ils comprennent seuls quoi faire | À faire |
| AND1 | Compilation sur GitHub (onglet Actions) | Coche verte, APK dans Releases | À faire |
| AND2 | Installer l'APK sur le téléphone, l'ouvrir en mode avion | Le jeu s'ouvre, les lettres arabes sont bien formées | À faire |
| AND3 | Toucher le haut-parleur d'un mot | Le téléphone lit le mot en arabe | À faire |
| AND4 | Bouton retour d'Android pendant la navigation | Revient à l'écran précédent ; quitte depuis l'accueil | À faire |
| AND5 | Installer une 2ᵉ APK par-dessus la 1ʳᵉ | Points et étoiles conservés | À faire |
| B3 | Après publication sur GitHub Pages : « Ajouter à l'écran d'accueil », puis mode avion | Le jeu s'ouvre depuis l'icône sans Internet | À faire (le site n'est pas encore publié) |
| B4 | Fermer complètement Chrome puis rouvrir | Points conservés | À faire |
| 14 | Vérification des liens externes | Aucun lien externe dans le jeu pour l'instant | Sans objet |
| 15 | Vérification des licences | Code et icônes créés pour le projet ; 3 polices sous licence SIL OFL 1.1 (fichiers de licence fournis) | À confirmer après choix de la licence |
| 16 | Vérification humaine du contenu | Un enseignant d'arabe relit les 28 lettres, leurs noms, formes et prononciations, les 66 questions, puis les 28 mots illustrés et leurs voyelles | À faire — obligatoire avant publication |

## C. Risques restants

- La progression est perdue si l'utilisateur efface les données de Chrome.
- Les prononciations écrites sont des approximations. La voix de synthèse du téléphone peut mal prononcer certaines lettres seules ; des enregistrements d'un enseignant sont prévus (`docs/ENREGISTREMENTS.md`).
- Les images sont les emoji du téléphone : leur dessin change selon la marque, et un très vieux téléphone peut afficher un carré vide pour la girafe 🦒.
- Le jeu « Tracer » vérifie la forme, pas l'ordre ni le sens des traits.
- Les lettres utilisent maintenant la police intégrée Noto Naskh Arabic : le rendu ne dépend plus du téléphone.
- Les tests automatiques ne remplacent pas un essai sur un téléphone ancien et peu puissant.
