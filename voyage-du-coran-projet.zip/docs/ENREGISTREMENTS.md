# Enregistrer la voix d'un enseignant

Pour l'instant, le jeu lit l'arabe avec la voix de synthèse du téléphone. Cette voix est provisoire : sa prononciation n'est pas toujours juste, surtout pour les lettres seules. La solution gratuite et fiable est d'enregistrer un enseignant du Centre Aboubacar Siddiq.

## Ce qu'il faut enregistrer

- **28 lettres** : le nom de chaque lettre (أَلِف، بَاء، تَاء…), dans l'ordre de `content/arabic-letters.json`.
- **28 mots** : le mot illustré de chaque lettre (أَسَد، بَطَّة، تُفَّاحَة…), dans l'ordre de `content/words.json`.

Cela fait 56 petits fichiers, environ 30 minutes de travail.

## Avant d'enregistrer

1. Demander à l'enseignant son **accord écrit** pour que sa voix soit utilisée dans le jeu, gratuitement et sans limite de durée. Noter son nom pour la page « À propos » s'il le souhaite.
2. Choisir une pièce calme, sans ventilateur ni moto devant la porte.
3. Sur le téléphone Android, ouvrir l'application **Enregistreur** (ou « Dictaphone »). Tenir le téléphone à environ 20 cm de la bouche.

## Enregistrer

- Un fichier par lettre ou par mot.
- Laisser une demi-seconde de silence avant et après.
- Nommer chaque fichier avec l'identifiant indiqué dans les fichiers de contenu :
  - lettres : `alif.m4a`, `ba.m4a`, `ta.m4a`… (le champ `id` de `arabic-letters.json`)
  - mots : `w-alif.m4a`, `w-ba.m4a`… (le champ `id` de `words.json`)

## Me les envoyer

Envoie-moi les fichiers dans la conversation. Je m'occupe de :

1. les convertir au format MP3, léger et lu par tous les téléphones ;
2. les ranger dans `content/audio/lettres/` et `content/audio/mots/` ;
3. les déclarer dans `content/audio.json`, par exemple `"ba": "content/audio/lettres/ba.mp3"`.

Dès qu'un fichier est déclaré, le jeu l'utilise à la place de la voix de synthèse. Les fichiers sont gardés pour le hors ligne après leur première écoute.

## Plus tard : Coran et hadiths

Les récitations du Coran ne doivent pas être enregistrées de cette façon sans vérification : elles demandent un récitateur qualifié, une relecture et une autorisation claire. Elles feront l'objet d'une étape séparée.
