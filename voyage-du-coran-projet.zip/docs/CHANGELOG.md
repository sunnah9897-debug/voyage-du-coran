# Journal des modifications

## 0.4.1 — 24 octobre 2026 — voix plus fiable sur Android

- L'application choisit d'elle-même le moteur de voix Google quand il est installé, même si le téléphone (Xiaomi, Samsung…) utilise un autre moteur par défaut.
- La voix arabe est revérifiée à chaque écoute et au retour des réglages : plus besoin de redémarrer après l'avoir installée.
- Paramètres › Voix affiche un diagnostic (moteur utilisé, voix arabe disponible ou à télécharger).
- Un message s'affiche à chaque appui sur le haut-parleur tant que la voix arabe manque.

## 0.4.0 — 24 octobre 2026 — application Android (APK)

- Nouveau dossier `android/` : application Android qui affiche le jeu en plein écran, sans Internet et sans autorisation Internet.
- Voix : dans l'application, l'arabe est lu par la synthèse vocale Android (pont `AndroidTTS`), avec un bouton « Installer la voix arabe » dans Paramètres.
- Bouton retour d'Android : revient à l'écran précédent du jeu.
- Compilation automatique de l'APK sur GitHub (`.github/workflows/apk.yml`) : les tests du jeu sont lancés, puis l'APK est publiée dans « Releases ».
- Clé de signature de test fixe : les nouvelles APK s'installent par-dessus les anciennes. Elle est à remplacer avant une diffusion large (voir `android/LISEZMOI.md`).

## 0.3.0 — 24 octobre 2026 — mode Enfant, images, voix et quatre jeux

- Premier lancement : choix du profil **Enfant** ou **Adolescent / adulte** (modifiable dans Paramètres).
- Mode Enfant : ciel de jour, soleil et dunes, couleurs vives, grosses tuiles colorées, et **Jamal le chameau**, mascotte originale qui parle à l'enfant et l'encourage.
- Un **mot illustré par lettre** (28 mots, emoji du téléphone) : أَسَد 🦁, بَطَّة 🦆, جَمَل 🐪… affiché sur chaque fiche de lettre.
- **Écoute** : bouton haut-parleur sur les lettres et les mots. Voix de synthèse du téléphone pour l'instant ; les enregistrements d'un enseignant la remplaceront (voir `docs/ENREGISTREMENTS.md`).
- Nouvel onglet **Jeux** avec 4 jeux :
  - « Quelle image ? » : mot → image, image → mot, lettre → image (8 manches) ;
  - Mémoire : 6 paires lettre ↔ image, étoiles selon le nombre de coups ;
  - Tracer : suivre la lettre en pointillés avec le doigt, avec une marge de tolérance pour les doigts d'enfants ;
  - Épeler : remettre les lettres d'un mot dans l'ordre (17 mots possibles).
- Points des jeux (5 par bonne réponse, meilleur score seulement), nouveau badge « Explorateur ».
- Moteur : vérification des mots (`validateWords`), jeux (`recordGame`, `buildMemoryDeck`, `traceScore`, `dilate`), avec leurs tests.
- Une progression des versions 0.1 et 0.2 reste lisible.

## 0.2.0 — 23 octobre 2026 — interface modernisée

- Nouvelle identité : ciel de nuit, motif d'étoiles à huit branches, lune, couleurs émeraude, or et bleu nuit.
- Polices intégrées (fonctionnent hors ligne) : Lexend (texte), Baloo Bhaijaan 2 (titres), Noto Naskh Arabic (lettres arabes).
- Parcours en forme de chemin : 5 étapes, 15 stations, étape suggérée mise en avant, 0 à 3 étoiles par exercice.
- Jeu plein écran : barre de progression animée, série de bonnes réponses, « +10 » qui s'envole, correction dans un panneau qui monte du bas.
- Sons fabriqués par le navigateur (aucun fichier audio) et vibration en cas d'erreur, désactivables.
- Écran de résultat avec étoiles animées et confettis quand l'exercice est réussi.
- Fiche de lettre redessinée : médaillon, ordre, points, liaison, prononciation, 4 formes ; flèches du clavier.
- Écran Progrès : anneau de progression, barres par étape, badges avec icônes.
- Nouvel écran Paramètres : sons, vibration, apparence (auto, clair, sombre), grande taille de texte, effacement de la progression.
- Moteur : nouvelle fonction `stars` (étoiles), avec son test.
- Aucune modification du contenu (lettres et exercices identiques à la 0.1.0).

## 0.1.0 — 18 octobre 2026 — premier prototype

- Accueil, alphabet de 28 lettres avec fiches, 15 exercices en 5 niveaux, quiz de 10 questions.
- Correction expliquée, points (meilleur score seulement), 6 badges, écran de progrès.
- Progression locale, effacement avec confirmation dans la page.
- Mode hors ligne (service worker) et installation sur l'écran d'accueil (manifest).
- Thème clair et sombre.
- Tests automatiques : 18 tests de logique et de contenu, 21 tests en navigateur.
- Aperçu en un seul fichier : `preview/apercu.html`.
- Contenu de l'alphabet en statut « brouillon », en attente de relecture par un enseignant.
