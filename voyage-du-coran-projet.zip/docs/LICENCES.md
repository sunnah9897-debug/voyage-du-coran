# Licences — proposition à décider par le fondateur

Aucune licence n'est encore appliquée. Tant qu'aucune licence n'est choisie, personne d'autre n'a légalement le droit de réutiliser le code, même s'il est visible sur GitHub.

## Inventaire actuel

| Élément | Qui détient les droits | Ressource externe ? |
| --- | --- | --- |
| Code (HTML, CSS, JavaScript, Python) | Le fondateur (écrit avec l'aide de l'IA pour le projet) | Non |
| Icônes (étoile à huit branches) | Le fondateur (dessinées pour le projet) | Non |
| Textes des lettres et des exercices | Le fondateur | Non |
| Lettres arabes elles-mêmes | Patrimoine commun, non protégé | — |
| Polices Lexend, Baloo Bhaijaan 2, Noto Naskh Arabic | Leurs auteurs ; licence SIL Open Font License 1.1 (copie dans `assets/fonts/`) | Oui — redistribution autorisée avec la licence |
| Sons | Fabriqués par le code du jeu, aucun fichier audio | Non |
| Mascotte « Jamal le chameau » (`assets/mascotte-jamal.svg`) | Le fondateur (dessinée pour le projet) | Non |
| Images des mots | Emoji affichés par le téléphone ; aucun fichier image n'est copié dans le projet | Non |
| Mots illustrés (`content/words.json`) | Le fondateur ; vocabulaire arabe courant | Non |
| Voix | Voix de synthèse du téléphone (non distribuée) ; futurs enregistrements avec accord écrit de l'enseignant | — |
| Audio, texte coranique, hadiths, traductions | Aucun pour l'instant | — |

## Proposition

**Code : licence MIT** ou **GPL-3.0**.

- MIT : tout le monde peut réutiliser et modifier le code, même dans un produit fermé ou payant, à condition de citer l'origine. Simple et très répandue.
- GPL-3.0 : même liberté, mais toute version modifiée et diffusée doit rester libre et gratuite dans les mêmes conditions. Protège mieux contre une récupération commerciale fermée.

Pour un projet à vocation de waqf, **GPL-3.0** correspond mieux à l'idée que l'œuvre reste ouverte à tous. MIT facilite davantage la reprise par d'autres organisations.

**Contenus pédagogiques originaux : Creative Commons BY-SA 4.0** — réutilisation et modification permises, avec citation de la source et partage dans les mêmes conditions.

**Contenus religieux futurs** : chaque source garde sa propre licence. Exemple : le texte coranique de Tanzil impose de ne pas le modifier et d'en citer la source. Ces conditions devront être relues avant toute intégration.

## Important

- Une licence logicielle n'est pas un waqf. Le waqf relève du droit applicable au Niger et doit être organisé avec des professionnels compétents.
- Une ressource gratuite sur Internet n'est pas forcément libre de droits : vérifier sa licence avant de l'ajouter.
