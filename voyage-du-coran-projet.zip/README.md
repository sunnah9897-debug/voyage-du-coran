# Le Voyage du Coran — رِحْلَةُ الْقُرْآنِ

Jeu éducatif gratuit pour apprendre l'alphabet arabe en famille.
Version **0.4.0 — application Android** (Phase 1). Projet fondé par Laouali Ousmane Abou-Soufianou (Maradi, Niger).

## Ce que contient cette version

- Écran d'accueil, alphabet de 28 lettres avec fiche détaillée (nom, prononciation approximative, points, 4 formes).
- 15 exercices en 5 niveaux (66 questions), avec correction expliquée après chaque réponse.
- Un quiz de révision de 10 questions tirées au hasard.
- Deux profils : Enfant (couleurs vives, Jamal le chameau) et Adolescent / adulte.
- Un mot illustré par lettre, avec bouton d'écoute (voix du téléphone en attendant de vrais enregistrements).
- Quatre jeux : « Quelle image ? », Mémoire, Tracer, Épeler.
- Parcours en forme de chemin avec 0 à 3 étoiles par exercice.
- Points (10 par bonne réponse, seul le meilleur score compte), 6 badges, écran de progrès.
- Sons et vibration (désactivables), confettis, écran Paramètres (apparence, taille du texte).
- Progression enregistrée uniquement sur l'appareil. Aucun compte, aucune publicité, aucune donnée envoyée.
- Fonctionne hors ligne après la première ouverture (sur un site en https).
- Thème clair et sombre, utilisable au clavier, adapté aux écrans de 320 px.

**Aucun verset du Coran ni aucun hadith n'est inclus.** Le contenu de l'alphabet est en statut « brouillon » tant qu'un enseignant ne l'a pas vérifié.

## Essayer le jeu sur un ordinateur (Windows)

Le jeu doit être ouvert par un petit serveur local (un double-clic sur `index.html` ne suffit pas : le navigateur bloque le chargement des fichiers de contenu).

1. Installer Python depuis https://www.python.org/downloads/ (cocher « Add Python to PATH » pendant l'installation).
2. Ouvrir le dossier `voyage-du-coran` dans l'Explorateur de fichiers.
3. Cliquer dans la barre d'adresse du dossier, taper `cmd` puis Entrée. Une fenêtre noire s'ouvre.
4. Taper : `python -m http.server 8000` puis Entrée.
5. Ouvrir Chrome à l'adresse : http://localhost:8000
6. Pour arrêter : revenir dans la fenêtre noire et appuyer sur Ctrl + C.

Plus simple : ouvrir `preview/voyage-du-coran-telephone.html` par double-clic (ou sur le téléphone, dans Chrome). Cette version tient en un seul fichier et marche sans Internet, puisque tout est dedans ; elle ne s'installe pas comme une application.

## Application Android (APK)

Le dossier `android/` contient l'application Android. GitHub la compile tout seul à chaque envoi de fichiers, puis publie l'APK dans l'onglet **Releases** du dépôt. Détails dans `android/LISEZMOI.md`.

## Organisation des fichiers

| Chemin | Rôle |
| --- | --- |
| `index.html` | La page du jeu |
| `css/style.css` | Couleurs et mise en page |
| `js/engine.js` | Logique pure : correction, points, badges, progression (testée automatiquement) |
| `js/app.js` | Écrans, navigation, voix, profils |
| `js/games.js` | Les quatre jeux |
| `content/arabic-letters.json` | Les 28 lettres |
| `content/exercises.json` | Les 15 exercices |
| `content/words.json` | Un mot illustré par lettre |
| `content/audio.json` | Liste des enregistrements de voix (vide pour l'instant) |
| `service-worker.js` | Mode hors ligne |
| `manifest.webmanifest` | Installation sur l'écran d'accueil |
| `assets/icons/` | Icônes |
| `assets/fonts/` | Polices intégrées et leurs licences |
| `assets/mascotte-jamal.svg` | Jamal le chameau, mascotte |
| `tests/` | Tests automatiques |
| `tools/build-preview.py` | Fabrique l'aperçu en un seul fichier |
| `android/` | Application Android (coquille qui affiche le jeu) |
| `.github/workflows/apk.yml` | Compilation automatique de l'APK sur GitHub |
| `docs/` | Tests, journal des modifications, licences, guide d'enregistrement de la voix |

## Modifier le contenu

- Les textes des lettres et des exercices sont dans `content/`. Après chaque modification, lancer les tests (ci-dessous) : ils détectent une réponse fausse, un choix inconnu ou un nombre de points incorrect.
- Après toute modification d'un fichier du jeu, augmenter `CACHE_VERSION` dans `service-worker.js`, sinon les téléphones garderont l'ancienne version.
- Tout nouveau fichier doit être ajouté à la liste `FILES` de `service-worker.js`.

## Lancer les tests

- Logique et contenu (Node.js 18 ou plus) : `node --test tests/engine.test.js tests/content.test.js`
- Navigateur, y compris hors ligne : `pip install playwright`, puis `python -m playwright install chromium`, puis `python tests/browser_test.py`

Résultats détaillés : `docs/TESTS.md`.

## Sauvegarde

Garder au moins trois copies : GitHub, une clé USB et Google Drive. Faire une nouvelle copie après chaque étape importante.

## Licence

Pas encore choisie. Voir `docs/LICENCES.md`.
