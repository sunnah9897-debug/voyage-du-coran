"""
Construit preview/apercu.html : tout le jeu dans UN seul fichier
(styles, scripts et contenus intégrés), pour un aperçu facile à partager.

Cet aperçu n'a pas de mode hors ligne (pas de service worker).
La vraie version reste index.html + les autres fichiers.

Lancer depuis le dossier du projet :  python tools/build-preview.py
"""
import base64, json, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
read = lambda p: open(os.path.join(ROOT, p), encoding="utf-8").read()

html = read("index.html")
body = html[html.index("<body>") + 6: html.index("<script")]
content = {
    "content/arabic-letters.json": json.loads(read("content/arabic-letters.json")),
    "content/exercises.json": json.loads(read("content/exercises.json")),
    "content/words.json": json.loads(read("content/words.json")),
    "content/audio.json": json.loads(read("content/audio.json")),
}
data = json.dumps(content, ensure_ascii=False).replace("</", "<\\/")

def inline_fonts(css):
    # Les polices deviennent des « data URI » : le fichier unique reste complet.
    def repl(m):
        data = open(os.path.join(ROOT, m.group(1)), "rb").read()
        return 'url("data:font/woff2;base64,' + base64.b64encode(data).decode() + '")'
    return re.sub(r'url\("\.\./(assets/fonts/[^"]+\.woff2)"\)', repl, css)

css = inline_fonts(read("css/style.css"))

out = f"""<title>Le Voyage du Coran</title>
<meta name="theme-color" content="#102a43">\n<meta name="claude:viewport-fit-sides" content="cover">
<style>
{css}
</style>
{body}
<script>window.VDC_CONTENT = {data};</script>
<script>
{read("js/engine.js")}
</script>
<script>
{read("js/app.js")}
</script>
<script>
{read("js/games.js")}
</script>
"""
os.makedirs(os.path.join(ROOT, "preview"), exist_ok=True)
with open(os.path.join(ROOT, "preview", "apercu.html"), "w", encoding="utf-8") as f:
    f.write(out)
print("preview/apercu.html créé (", len(out.encode()) // 1024, "Ko )")

full = ('<!doctype html>\n<html lang="fr">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
        + out.replace("</style>", "</style>\n</head>\n<body>", 1) + "\n</body>\n</html>\n")
with open(os.path.join(ROOT, "preview", "voyage-du-coran-telephone.html"), "w", encoding="utf-8") as f:
    f.write(full)
print("preview/voyage-du-coran-telephone.html créé (", len(full.encode()) // 1024, "Ko )")
