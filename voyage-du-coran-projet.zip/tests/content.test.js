// Vérifie la cohérence des fichiers de contenu. Lancer avec :  node --test tests/
const test = require("node:test");
const assert = require("node:assert");
const Engine = require("../js/engine.js");
const letters = require("../content/arabic-letters.json");
const exercises = require("../content/exercises.json");

test("le contenu ne contient aucune erreur détectable", () => {
  assert.deepStrictEqual(Engine.validateContent(letters, exercises), []);
});

test("28 lettres, numérotées de 1 à 28 dans l'ordre", () => {
  assert.strictEqual(letters.letters.length, 28);
  letters.letters.forEach((l, i) => assert.strictEqual(l.order, i + 1));
});

test("chaque lettre est un seul caractère arabe, sans doublon", () => {
  const seen = new Set();
  letters.letters.forEach(l => {
    assert.strictEqual([...l.char].length, 1, l.id);
    assert.match(l.char, /^[ء-ي]$/, l.id);
    assert.ok(!seen.has(l.char), "doublon " + l.id);
    seen.add(l.char);
  });
});

test("les 6 lettres qui ne se lient pas à la suivante sont bien marquées", () => {
  const non = letters.letters.filter(l => !l.connectsToNext).map(l => l.char).join("");
  assert.strictEqual(non, "ادذرزو");
});

test("15 exercices répartis en 5 niveaux de 3", () => {
  assert.strictEqual(exercises.exercises.length, 15);
  for (let lv = 1; lv <= 5; lv++) {
    assert.strictEqual(exercises.exercises.filter(e => e.level === lv).length, 3);
  }
});

test("le validateur détecte bien une erreur volontaire", () => {
  const broken = JSON.parse(JSON.stringify(exercises));
  broken.exercises[0].questions[0].answer = "ta";   // réponse fausse
  broken.exercises[9].questions[0].answer = 3;      // mauvais nombre de points
  assert.ok(Engine.validateContent(letters, broken).length >= 2);
});

test("le contenu reste en brouillon tant qu'aucun relecteur n'est indiqué", () => {
  if (!letters.meta.reviewer) assert.strictEqual(letters.meta.status, "brouillon");
});

test("mots illustrés : un par lettre, commençant par la bonne lettre, épellation exacte", () => {
  const words = require("../content/words.json");
  assert.deepStrictEqual(Engine.validateWords(letters, words), []);
  assert.strictEqual(words.words.length, 28);
  assert.ok(words.words.filter(w => w.spell).length >= 10, "au moins 10 mots à épeler");
});

test("le validateur de mots détecte une erreur volontaire", () => {
  const words = JSON.parse(JSON.stringify(require("../content/words.json")));
  words.words[4].spell = ["jim", "lam", "mim"];       // mauvais ordre
  words.words[5].letter = "kha";                       // mauvaise lettre
  assert.ok(Engine.validateWords(letters, words).length >= 2);
});

test("les mots restent en brouillon tant qu'aucun relecteur n'est indiqué", () => {
  const words = require("../content/words.json");
  if (!words.meta.reviewer) assert.strictEqual(words.meta.status, "brouillon");
});
