"""
Test du prototype dans un vrai navigateur (Chromium sans écran), taille téléphone.

Prérequis :  pip install playwright  puis  python -m playwright install chromium
Lancer depuis le dossier du projet :  python tests/browser_test.py
Captures d'écran enregistrées dans tests/screenshots/.
"""
import json, os, sys, threading, functools, http.server, socketserver
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 8123
URL = f"http://localhost:{PORT}/"
SHOTS = os.path.join(ROOT, "tests", "screenshots")
os.makedirs(SHOTS, exist_ok=True)
EX = json.load(open(os.path.join(ROOT, "content", "exercises.json"), encoding="utf-8"))
results = []

def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("RÉUSSI  " if ok else "ÉCHEC   ") + name + (f" — {detail}" if detail else ""))

def serve():
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)
    handler.log_message = lambda *a: None
    socketserver.TCPServer.allow_reuse_address = True
    httpd = socketserver.TCPServer(("127.0.0.1", PORT), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd

def points(page):
    return int(page.locator("#points-pill").inner_text().split()[0])

def play(page, ex, correct=True):
    page.goto(URL + "#/parcours")  # passe par la carte, comme un utilisateur
    page.click(f'a[href="#/jouer/{ex["id"]}"]')
    for q in ex["questions"]:
        page.wait_for_selector(".choice")
        if q["type"] == "order":
            seq = q["answer"] if correct else list(reversed(q["answer"]))
            for v in seq:
                page.click(f'.choice[data-value="{v}"]')
            page.click("text=Valider")
        else:
            if correct:
                v = str(q["answer"])
            else:
                v = next(str(c) for c in q["choices"] if c != q["answer"])
            page.click(f'.choice[data-value="{v}"]')
        page.wait_for_selector(".feedback")
        page.locator(".feedback .btn").click()
    page.wait_for_selector(".score-big")
    return page.locator(".score-big").inner_text()

httpd = serve()
with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 360, "height": 740}, device_scale_factor=2,
                              is_mobile=True, has_touch=True, locale="fr-FR")
    page = ctx.new_page()
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append(str(e)))

    # 1. Ouverture : au premier lancement, on choisit le profil
    page.goto(URL)
    page.wait_for_selector("#mode-adult")
    check("1a. Premier lancement : choix Enfant / Adulte", page.locator("#mode-kid").count() == 1)
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/00-bienvenue.png")
    page.click("#mode-adult")
    page.wait_for_selector(".hero")
    check("1. Ouverture de l'application", "Le Voyage du Coran" in page.title())
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/01-accueil.png")

    # 2-4. Alphabet, affichage arabe, sens droite-gauche
    page.click('.tabbar a[data-tab="alphabet"]')
    page.wait_for_selector(".letter-tile")
    tiles = page.locator(".letter-tile")
    check("2. Navigation vers l'alphabet", tiles.count() == 28, f"{tiles.count()} lettres affichées")
    first = tiles.nth(0).locator(".ar").inner_text()
    direction = page.eval_on_selector(".letter-grid", "e => getComputedStyle(e).direction")
    box1 = tiles.nth(0).bounding_box(); box2 = tiles.nth(1).bounding_box()
    check("3. Lettres arabes affichées", first == "ا", f"première lettre : {first}")
    check("4. Sens de lecture droite-gauche", direction == "rtl" and box1["x"] > box2["x"],
          "alif est à droite de bâ'")
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/02-alphabet.png")
    tiles.nth(1).click()
    page.wait_for_selector(".big-letter")
    forms = page.locator(".form-box").count()
    check("2b. Fiche d'une lettre (4 formes)", forms == 4 and "bâ'" in page.inner_text("h1"))
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/03-lettre-ba.png", full_page=True)

    # 5-6. Mauvaises réponses : 0 point, correction affichée
    score = play(page, EX["exercises"][0], correct=False)
    check("5a. Réponses incorrectes comptées comme fausses", score.startswith("0 /"), score)
    check("6a. Aucun point pour des réponses fausses", points(page) == 0)
    page.goto(URL + "#/jouer/e1")
    page.wait_for_selector(".choice")
    q = EX["exercises"][0]["questions"][0]
    wrong = next(c for c in q["choices"] if c != q["answer"])
    page.click(f'.choice[data-value="{wrong}"]')
    marked = page.locator(".choice.correct").count() == 1 and page.locator(".choice.wrong").count() == 1
    check("5b. La correction montre la bonne réponse et l'erreur", marked)
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/04-correction.png", full_page=True)

    # 5-6. Les 15 exercices, toutes réponses justes
    total_q = 0
    all_ok = True
    for ex in EX["exercises"]:
        s = play(page, ex, correct=True)
        n = len(ex["questions"]); total_q += n
        if s.replace(" ", "") != f"{n}/{n}":
            all_ok = False; print("   ", ex["id"], s)
        if ex["id"] == "e15":
            page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/05-resultat.png", full_page=True)
    check("5c. Les 15 exercices fonctionnent avec les bonnes réponses", all_ok, f"{total_q} questions")
    expected = total_q * EX["meta"]["pointsPerCorrectAnswer"]
    check("6b. Calcul des points", points(page) == expected, f"{points(page)} attendu {expected}")
    play(page, EX["exercises"][0], correct=True)
    check("6c. Rejouer ne gonfle pas les points", points(page) == expected)

    # 7, 12. Sauvegarde et rechargement
    page.reload(); page.wait_for_selector(".hero")
    check("7. Progression conservée après rechargement", points(page) == expected)
    page.goto(URL + "#/progres"); page.wait_for_selector(".badge")
    earned = page.locator(".badge.earned").count()
    check("7b. Écran de progrès (15/15, badges)", "15/15" in page.inner_text(".stats") and earned >= 5, f"{earned} badges")
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/06-progres.png", full_page=True)

    # Quiz
    page.goto(URL + "#/quiz"); page.wait_for_selector(".choice")
    check("Quiz : 10 questions", "sur 10" in page.inner_text(".screen"))

    # 10. Clavier
    page.goto(URL + "#/jouer/e2"); page.wait_for_selector(".choice")
    page.locator(".choice").first.focus(); page.keyboard.press("Enter")
    check("10. Réponse possible au clavier", page.locator(".feedback").count() == 1)

    # 9. Petit écran (320 px) sans défilement horizontal
    small = browser.new_context(viewport={"width": 320, "height": 568}, is_mobile=True)
    sp = small.new_page()
    sp.goto(URL); sp.wait_for_selector("#mode-adult"); sp.click("#mode-adult"); sp.wait_for_selector(".hero")
    overflow = []
    for route in ["#/accueil", "#/parcours", "#/alphabet", "#/lettre/ba", "#/jouer/e15", "#/progres", "#/parametres", "#/a-propos"]:
        sp.goto(URL + route); sp.wait_for_timeout(300)
        if sp.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth"):
            overflow.append(route)
    check("9. Affichage sur petit écran (320 px)", not overflow, ", ".join(overflow) or "aucun débordement")
    sp.goto(URL + "#/jouer/e15"); sp.wait_for_selector(".choice")
    sp.screenshot(path=f"{SHOTS}/07-petit-ecran.png", full_page=True)
    small.close()

    # 11. Hors ligne
    page.goto(URL)
    page.evaluate("navigator.serviceWorker.ready")
    page.reload(); page.wait_for_selector(".hero")
    controlled = page.evaluate("!!navigator.serviceWorker.controller")
    ctx.set_offline(True)
    page.reload(); page.wait_for_selector(".hero", timeout=5000)
    page.goto(URL + "#/jouer/e3"); page.wait_for_selector(".choice", timeout=5000)
    page.goto(URL + "#/lettre/ya"); page.wait_for_selector(".big-letter", timeout=5000)
    check("11. Fonctionnement hors ligne", controlled and points(page) == expected,
          "accueil, exercice et fiche ouverts sans réseau")
    ctx.set_offline(False)

    # 13. Gestion des erreurs
    page.goto(URL + "#/page-inexistante"); page.wait_for_selector("h1")
    check("13a. Adresse inconnue gérée", "introuvable" in page.inner_text("h1").lower())
    page.evaluate("localStorage.setItem('vdc.progress.v1', '{cassé')")
    page.goto(URL + "#/accueil"); page.reload(); page.wait_for_selector(".hero")
    check("13b. Progression abîmée : le jeu démarre quand même", points(page) == 0)

    # 8. Réinitialisation
    play(page, EX["exercises"][0], correct=True)
    page.goto(URL + "#/parametres"); page.wait_for_selector(".btn.danger")
    page.click(".btn.danger")
    page.click("#confirm-reset")
    page.wait_for_timeout(200)
    check("8. Réinitialisation de la progression", points(page) == 0)

    # ---------- Les quatre jeux ----------
    WORDS = json.load(open(os.path.join(ROOT, "content", "words.json"), encoding="utf-8"))
    def result_text():
        page.wait_for_selector(".score-big"); return page.locator(".score-big").inner_text().replace(" ", "")

    page.goto(URL + "#/jeux"); page.wait_for_selector(".game-card")
    check("Jeux : menu avec 4 jeux", page.locator(".game-card").count() == 4)
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/09-jeux.png", full_page=True)

    # Quelle image ?
    page.click('a[href="#/jeu/images"]')
    for r in range(8):
        page.wait_for_selector(f'.section[data-answer]')
        ans = page.get_attribute(".section[data-answer]", "data-answer")
        if r == 1: page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/10-jeu-images.png")
        page.click(f'button[data-value="{ans}"]')
        page.locator(".feedback .btn").click()
    check("Jeu « Quelle image ? » : 8 manches justes", result_text() == "8/8")

    # Mémoire
    page.goto(URL + "#/jeux"); page.click('a[href="#/jeu/memory"]')
    page.wait_for_selector(".card")
    pairs = list(dict.fromkeys(page.eval_on_selector_all(".card", "els => els.map(e => e.dataset.pair)")))
    page.locator(f'.card[data-pair="{pairs[0]}"][data-kind="letter"]').click()
    page.wait_for_timeout(400); page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/11-jeu-memoire.png")
    page.locator(f'.card[data-pair="{pairs[0]}"][data-kind="image"]').click()
    for pr in pairs[1:]:
        page.locator(f'.card[data-pair="{pr}"][data-kind="letter"]').click()
        page.locator(f'.card[data-pair="{pr}"][data-kind="image"]').click()
    check("Jeu de mémoire : 6 paires trouvées", page.locator(".card.found").count() == 12)
    page.wait_for_selector(".feedback .btn"); page.locator(".feedback .btn").click()
    check("Jeu de mémoire : 6 coups = 3 étoiles", result_text() == "6/6")

    # Épeler
    page.goto(URL + "#/jeux"); page.click('a[href="#/jeu/spell"]')
    for r in range(6):
        page.wait_for_selector(".section[data-answer]")
        ans = page.get_attribute(".section[data-answer]", "data-answer").split(",")
        for lid in ans:
            page.locator(f'.tile[data-letter="{lid}"]:not([disabled])').first.click()
        if r == 0: page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/12-jeu-epeler.png")
        page.locator(".feedback .btn").click()
    check("Jeu « Épeler » : 6 mots justes", result_text() == "6/6")

    # Tracer : un tracé à côté échoue, un tracé sur la lettre réussit
    page.goto(URL + "#/jeux"); page.click('a[href="#/jeu/trace"]')
    def trace_on_letter():
        page.wait_for_selector(".trace-wrap[data-ready]")
        cells = page.evaluate("""() => {
          const g = document.querySelector('canvas.guide'), N = 48;
          const o = document.createElement('canvas'); o.width = N; o.height = N;
          const c = o.getContext('2d'); c.drawImage(g, 0, 0, N, N);
          const d = c.getImageData(0, 0, N, N).data, out = [];
          for (let y = 0; y < N; y += 2) for (let x = 0; x < N; x += 2) if (d[(y * N + x) * 4 + 3] > 150) out.push([x, y]);
          const r = document.querySelector('canvas.ink').getBoundingClientRect();
          return out.map(([x, y]) => [r.left + (x + .5) * r.width / N, r.top + (y + .5) * r.height / N]);
        }""")
        for x, y in cells:
            page.mouse.move(x, y); page.mouse.down(); page.mouse.move(x + 1, y); page.mouse.up()
        return len(cells)
    page.wait_for_selector(".trace-wrap[data-ready]")
    box = page.locator("canvas.ink").bounding_box()
    page.mouse.move(box["x"] + 12, box["y"] + 12); page.mouse.down()
    page.mouse.move(box["x"] + 60, box["y"] + 20, steps=8); page.mouse.up()
    page.click("#trace-check")
    check("Tracer : un gribouillis à côté de la lettre est refusé", "Encore un essai" in page.inner_text(".feedback"))
    page.locator(".feedback .btn").click()
    n = trace_on_letter()
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/13-jeu-tracer.png")
    page.click("#trace-check")
    first_ok = "Très beau tracé" in page.inner_text(".feedback")
    page.locator(".feedback .btn").click()
    passed = 1 if first_ok else 0
    for r in range(4):
        trace_on_letter(); page.click("#trace-check")
        if "Très beau tracé" in page.inner_text(".feedback"): passed += 1
        page.locator(".feedback .btn").click()
    check("Tracer : un tracé qui suit la lettre est accepté", passed == 5, f"{passed}/5 lettres acceptées")
    result_text()
    page.goto(URL + "#/progres"); page.wait_for_selector(".badge")
    check("Badge « Explorateur » après les 4 jeux", page.locator(".badge.earned", has_text="Explorateur").count() == 1)

    # Mode enfant
    page.goto(URL + "#/parametres"); page.wait_for_selector(".segmented")
    page.click('button:has-text("Enfant")')
    page.goto(URL + "#/accueil"); page.wait_for_selector(".hero")
    kid = page.evaluate("document.documentElement.dataset.mode")
    check("Mode enfant : activé avec Jamal", kid == "kid" and page.locator(".say .mascot").count() == 1)
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/14-enfant-accueil.png")
    page.goto(URL + "#/lettre/jim"); page.wait_for_selector(".word-card")
    check("Fiche de lettre : mot illustré et bouton d'écoute", "جَمَل" in page.inner_text(".word-card") and page.locator(".speak").count() >= 2)
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/15-enfant-lettre.png", full_page=True)
    page.goto(URL + "#/jouer/e2"); page.wait_for_selector(".choice")
    page.locator(".choice").first.click(); page.wait_for_timeout(500)
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/16-enfant-question.png")
    small2 = browser.new_context(viewport={"width": 320, "height": 568}, is_mobile=True)
    sp2 = small2.new_page()
    sp2.goto(URL); sp2.wait_for_selector("#mode-kid"); sp2.click("#mode-kid"); sp2.wait_for_selector(".hero")
    over2 = []
    for route in ["#/accueil", "#/jeux", "#/jeu/images", "#/jeu/memory", "#/jeu/trace", "#/jeu/spell", "#/lettre/ya", "#/progres", "#/parametres"]:
        sp2.goto(URL + route); sp2.wait_for_timeout(350)
        if sp2.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth"):
            over2.append(route)
    check("Mode enfant et jeux sur petit écran (320 px)", not over2, ", ".join(over2) or "aucun débordement")
    small2.close()
    page.goto(URL + "#/parametres"); page.wait_for_selector(".segmented")
    page.click('button:has-text("Adulte")')

    # Application Android simulée : la voix passe par le pont « AndroidTTS »
    actx = browser.new_context(viewport={"width": 360, "height": 740}, is_mobile=True, has_touch=True)
    actx.add_init_script("""window.AndroidTTS = { said: [], speak(t) { this.said.push(t); return true; },
      hasArabic() { return true; }, ready() { return true; }, openTtsSettings() { this.opened = true; },
      status() { return "Moteur : com.google.android.tts · voix arabe disponible (code 0)"; } };""")
    ap = actx.new_page()
    ap.goto(URL); ap.wait_for_selector("#mode-kid"); ap.click("#mode-kid"); ap.wait_for_selector(".hero")
    ap.goto(URL + "#/lettre/ba"); ap.wait_for_selector(".word-card .speak")
    ap.locator(".word-card .speak").click()
    said = ap.evaluate("window.AndroidTTS.said")
    sw = ap.evaluate("navigator.serviceWorker ? navigator.serviceWorker.getRegistrations().then(r => r.length) : 0")
    check("Android : la voix passe par la synthèse vocale du téléphone", said == ["بَطَّة"], str(said))
    check("Android : pas de service worker dans l'application", sw == 0)
    ap.goto(URL + "#/parametres"); ap.wait_for_selector("#open-tts")
    ap.click("#open-tts")
    check("Android : bouton « Installer la voix arabe »", ap.evaluate("window.AndroidTTS.opened === true"))
    check("Android : diagnostic de la voix affiché", "com.google.android.tts" in ap.inner_text("#tts-status"))
    ap.evaluate("window.AndroidTTS.speak = () => false")
    ap.goto(URL + "#/lettre/ta"); ap.wait_for_selector(".word-card .speak"); ap.locator(".word-card .speak").click()
    check("Android : message clair si la voix arabe manque", "Installer la voix arabe" in " ".join(ap.locator(".toast").all_inner_texts()))
    actx.close()

    # Polices intégrées réellement chargées
    page.goto(URL + "#/alphabet"); page.wait_for_selector(".letter-tile")
    page.evaluate("document.fonts.ready")
    loaded = page.evaluate("['Noto Naskh Arabic','Lexend','Baloo Bhaijaan 2'].map(f => document.fonts.check('16px \"' + f + '\"', 'ب a'))")
    check("Polices intégrées chargées", all(loaded), str(loaded))

    # Paramètres : thème sombre et grand texte conservés
    page.goto(URL + "#/parametres"); page.wait_for_selector(".segmented")
    page.click('button:has-text("Sombre")'); page.click('button:has-text("Grande")')
    page.reload(); page.wait_for_selector(".segmented")
    th = page.evaluate("[document.documentElement.dataset.theme, document.documentElement.classList.contains('text-large')]")
    check("Paramètres conservés (thème, taille du texte)", th == ["dark", True], str(th))
    page.wait_for_timeout(350); page.screenshot(path=f"{SHOTS}/08-parametres-sombre.png", full_page=True)
    page.click('button:has-text("Auto")'); page.click('button:has-text("Normale")')

    check("Aucune erreur JavaScript", not errors, "; ".join(errors[:3]))
    browser.close()
httpd.shutdown()

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)}/{len(results)} tests réussis")
sys.exit(1 if failed else 0)
