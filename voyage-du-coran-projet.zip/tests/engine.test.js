// Tests automatiques du moteur. Lancer avec :  node --test tests/
const test = require("node:test");
const assert = require("node:assert");
const Engine = require("../js/engine.js");
const exercises = require("../content/exercises.json");

const PTS = exercises.meta.pointsPerCorrectAnswer;

test("une bonne réponse est acceptée, une mauvaise refusée", () => {
  const q = { type: "nameToLetter", letter: "ba", choices: ["ba", "ta"], answer: "ba" };
  assert.strictEqual(Engine.isCorrect(q, "ba"), true);
  assert.strictEqual(Engine.isCorrect(q, "ta"), false);
  assert.strictEqual(Engine.isCorrect(q, undefined), false);
});

test("question de points : 0 n'est pas confondu avec « aucune réponse »", () => {
  const q = { type: "dots", letter: "ha", choices: [0, 1, 2, 3], answer: 0 };
  assert.strictEqual(Engine.isCorrect(q, 0), true);
  assert.strictEqual(Engine.isCorrect(q, "0"), false);
  assert.strictEqual(Engine.isCorrect(q, null), false);
});

test("question d'ordre : l'ordre exact est exigé", () => {
  const q = { type: "order", choices: ["ta", "alif", "ba"], answer: ["alif", "ba", "ta"] };
  assert.strictEqual(Engine.isCorrect(q, ["alif", "ba", "ta"]), true);
  assert.strictEqual(Engine.isCorrect(q, ["ba", "alif", "ta"]), false);
  assert.strictEqual(Engine.isCorrect(q, ["alif", "ba"]), false);
  assert.strictEqual(Engine.isCorrect(q, "alif"), false);
});

test("points : 10 par bonne réponse, seul le meilleur score compte", () => {
  const p = Engine.newProgress();
  Engine.recordExercise(p, "e1", 3, 4);
  assert.strictEqual(Engine.totalPoints(p, PTS), 30);
  Engine.recordExercise(p, "e1", 1, 4);          // moins bien : on ne perd rien
  assert.strictEqual(Engine.totalPoints(p, PTS), 30);
  Engine.recordExercise(p, "e1", 4, 4);          // mieux : on gagne la différence
  assert.strictEqual(Engine.totalPoints(p, PTS), 40);
  Engine.recordExercise(p, "e1", 4, 4);          // rejouer ne gonfle pas les points
  assert.strictEqual(Engine.totalPoints(p, PTS), 40);
  assert.strictEqual(p.exercises.e1.attempts, 4);
});

test("points du quiz : 5 par bonne réponse", () => {
  const p = Engine.newProgress();
  Engine.recordQuiz(p, 7, 10);
  assert.strictEqual(Engine.totalPoints(p, PTS), 35);
});

test("un exercice est réussi à partir de 75 % de bonnes réponses", () => {
  assert.strictEqual(Engine.isPassed({ best: 3, total: 4 }, 0.75), true);
  assert.strictEqual(Engine.isPassed({ best: 2, total: 4 }, 0.75), false);
  assert.strictEqual(Engine.isPassed({ best: 4, total: 5 }, 0.75), true);
  assert.strictEqual(Engine.isPassed({ best: 3, total: 5 }, 0.75), false);
  assert.strictEqual(Engine.isPassed(undefined, 0.75), false);
});

test("la progression enregistrée est relue correctement", () => {
  const p = Engine.newProgress();
  Engine.recordExercise(p, "e2", 4, 4);
  const again = Engine.loadProgress(JSON.stringify(p), exercises);
  assert.deepStrictEqual(again, p);
});

test("une progression abîmée ou trafiquée ne fait pas planter le jeu", () => {
  assert.deepStrictEqual(Engine.loadProgress("pas du json", exercises), Engine.newProgress());
  assert.deepStrictEqual(Engine.loadProgress("null", exercises), Engine.newProgress());
  const bad = { version: 1, exercises: { e1: { best: 9999, total: 4, attempts: -3 }, inconnu: { best: 4 } },
                quiz: { best: "abc", total: 10, attempts: 1 } };
  const p = Engine.loadProgress(JSON.stringify(bad), exercises);
  assert.strictEqual(p.exercises.e1.best, 4);       // limité au nombre de questions
  assert.strictEqual(p.exercises.e1.attempts, 0);
  assert.strictEqual("inconnu" in p.exercises, false);
  assert.strictEqual(p.quiz.best, 0);
});

test("badges", () => {
  const p = Engine.newProgress();
  let b = Engine.badges(p, exercises);
  assert.strictEqual(b.filter(x => x.earned).length, 0);
  exercises.exercises.forEach(e => Engine.recordExercise(p, e.id, e.questions.length, e.questions.length));
  Engine.recordQuiz(p, 8, 10);
  assert.strictEqual(Engine.badges(p, exercises).find(x => x.id === "explorer").earned, false);
  Engine.GAME_IDS.forEach(g => Engine.recordGame(p, g, 1, 5));
  b = Engine.badges(p, exercises);
  assert.strictEqual(b.every(x => x.earned), true);
});

test("le quiz tire 10 questions toutes différentes", () => {
  let seed = 1;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const quiz = Engine.buildQuiz(exercises, 10, rnd);
  assert.strictEqual(quiz.length, 10);
  assert.strictEqual(new Set(quiz.map(q => q.id)).size, 10);
});

test("le mélange des choix garde les mêmes éléments et ne modifie pas l'original", () => {
  const orig = ["a", "b", "c", "d"];
  const s = Engine.shuffled(orig);
  assert.deepStrictEqual([...s].sort(), orig);
  assert.deepStrictEqual(orig, ["a", "b", "c", "d"]);
});

test("étoiles : 3 sans faute, 2 réussi, 1 moitié, 0 sinon", () => {
  assert.strictEqual(Engine.stars({ best: 4, total: 4 }, 0.75), 3);
  assert.strictEqual(Engine.stars({ best: 3, total: 4 }, 0.75), 2);
  assert.strictEqual(Engine.stars({ best: 2, total: 4 }, 0.75), 1);
  assert.strictEqual(Engine.stars({ best: 1, total: 4 }, 0.75), 0);
  assert.strictEqual(Engine.stars(undefined, 0.75), 0);
});

test("jeux : meilleur score gardé, 5 points par bonne réponse, jeu inconnu ignoré", () => {
  const p = Engine.newProgress();
  Engine.recordGame(p, "images", 6, 8);
  Engine.recordGame(p, "images", 3, 8);
  Engine.recordGame(p, "inconnu", 8, 8);
  assert.strictEqual(p.games.images.best, 6);
  assert.strictEqual(p.games.images.attempts, 2);
  assert.strictEqual("inconnu" in p.games, false);
  assert.strictEqual(Engine.totalPoints(p, PTS), 30);
  const again = Engine.loadProgress(JSON.stringify(p), exercises);
  assert.deepStrictEqual(again.games, p.games);
});

test("une ancienne progression (sans jeux) reste lisible", () => {
  const old = { version: 1, exercises: { e1: { best: 4, total: 4, attempts: 1 } }, quiz: { best: 0, total: 0, attempts: 0 } };
  const p = Engine.loadProgress(JSON.stringify(old), exercises);
  assert.strictEqual(p.exercises.e1.best, 4);
  assert.deepStrictEqual(p.games, {});
});

test("jeu de mémoire : 6 paires = 12 cartes, chaque paire une fois lettre et une fois image", () => {
  const words = require("../content/words.json");
  const deck = Engine.buildMemoryDeck(words, 6);
  assert.strictEqual(deck.length, 12);
  const byPair = {};
  deck.forEach(c => { (byPair[c.pair] = byPair[c.pair] || []).push(c.kind); });
  assert.strictEqual(Object.keys(byPair).length, 6);
  Object.values(byPair).forEach(k => assert.deepStrictEqual(k.sort(), ["image", "letter"]));
});

test("tracé : bien recouvrir la lettre réussit, gribouiller à côté échoue", () => {
  const mask = [1, 1, 1, 1, 0, 0, 0, 0];
  const good = Engine.traceScore(mask, [1, 1, 1, 0, 0, 0, 0, 0]);
  assert.strictEqual(good.coverage, 0.75);
  assert.strictEqual(Engine.tracePassed(good), true);
  const outside = Engine.traceScore(mask, [0, 0, 0, 0, 1, 1, 1, 1]);
  assert.strictEqual(Engine.tracePassed(outside), false);
  const everywhere = Engine.traceScore(mask, [1, 1, 1, 1, 1, 1, 1, 1]);
  assert.strictEqual(everywhere.spill, 0.5);
  assert.strictEqual(Engine.tracePassed(everywhere), false);
  assert.strictEqual(Engine.tracePassed(Engine.traceScore(mask, [0, 0, 0, 0, 0, 0, 0, 0])), false);
});

test("retrait des voyelles", () => {
  assert.strictEqual(Engine.stripHarakat("جَمَل"), "جمل");
  assert.strictEqual(Engine.stripHarakat("دُبّ"), "دب");
});

test("tracé : un trait juste à côté d'une lettre fine est toléré grâce à la zone élargie", () => {
  // grille 5 × 5, lettre = colonne du milieu
  const N = 5, mask = new Array(25).fill(0);
  for (let y = 0; y < N; y++) mask[y * N + 2] = 1;
  const ink = new Array(25).fill(0);
  for (let y = 0; y < N; y++) { ink[y * N + 1] = 1; ink[y * N + 2] = 1; ink[y * N + 3] = 1; }  // trait large
  assert.strictEqual(Engine.tracePassed(Engine.traceScore(mask, ink)), false);              // sans tolérance
  const zone = Engine.dilate(mask, N, 1);
  assert.strictEqual(Engine.traceScore(mask, ink, zone).spill, 0);
  assert.strictEqual(Engine.tracePassed(Engine.traceScore(mask, ink, zone)), true);       // avec tolérance
  const far = new Array(25).fill(0); far[0] = far[5] = far[10] = 1;                        // loin de la lettre
  assert.strictEqual(Engine.tracePassed(Engine.traceScore(mask, far, zone)), false);
});
