# Application Android du Voyage du Coran

L'application Android est une « coquille » qui affiche le jeu web du dépôt (`index.html`, `css/`, `js/`, `content/`, `assets/`) en plein écran, sans Internet.

## Comment l'APK est fabriquée

1. À chaque envoi de fichiers sur la branche `main` de GitHub, le fichier `.github/workflows/apk.yml` se lance tout seul.
2. GitHub teste la logique du jeu, copie le jeu web dans l'application, puis compile l'APK (environ 5 à 8 minutes).
3. L'APK apparaît dans l'onglet **Releases** du dépôt, sous le nom `voyage-du-coran-N.apk`, N étant le numéro de compilation.

Chaque nouvelle APK s'installe par-dessus la précédente : la progression des joueurs est conservée.

## Ce que fait l'application

| Élément | Détail |
| --- | --- |
| Fichier principal | `app/src/main/java/ne/sunnah/voyageducoran/MainActivity.java` |
| Identifiant | `ne.sunnah.voyageducoran` |
| Android minimum | 7.0 (API 24) |
| Internet | Non demandé : tout est dans l'APK |
| Autorisation | Vibration seulement |
| Voix | Synthèse vocale du téléphone, via le pont JavaScript `AndroidTTS` |
| Bouton retour | Revient à l'écran précédent du jeu |

## Clé de signature : à changer avant une diffusion large

L'APK est signée avec `app/cle-de-test.keystore`, dont le mot de passe est écrit dans `app/build.gradle`. Cette clé est **publique**, car le dépôt est public. Elle suffit pour tester en famille et au Centre. En revanche, n'importe qui pourrait signer une fausse mise à jour avec elle.

Avant de diffuser l'application largement (site web, Play Store, partage public) :

1. créer une clé privée ;
2. la ranger dans les **Secrets** du dépôt GitHub (Settings › Secrets and variables › Actions) ;
3. adapter `app/build.gradle` et le workflow pour lire ces secrets ;
4. garder une copie de la clé en lieu sûr, sur au moins deux supports. Sans cette clé, il devient impossible de publier des mises à jour.

Claude peut préparer ces étapes le moment venu. Attention : un changement de clé oblige à désinstaller l'ancienne application une fois.
