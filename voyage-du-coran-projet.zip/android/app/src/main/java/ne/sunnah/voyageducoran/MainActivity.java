package ne.sunnah.voyageducoran;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.Locale;

/**
 * Le Voyage du Coran — écran unique de l'application Android.
 *
 * L'application affiche le jeu web (dossier assets/www, copié depuis la racine du dépôt)
 * dans une WebView. Les fichiers sont servis depuis le téléphone lui-même :
 * aucune connexion Internet n'est utilisée.
 *
 * Le jeu web appelle « AndroidTTS » pour faire lire l'arabe par la synthèse vocale
 * du téléphone, car la voix du navigateur n'existe pas dans une WebView.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/www/index.html";

    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile boolean arabicAvailable = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);              // progression et réglages (localStorage)
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (HOST.equals(url.getHost())) return false;   // page du jeu : on reste dans l'application
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, url));   // lien externe : navigateur du téléphone
                } catch (Exception ignored) {
                    // aucun navigateur : on ignore le lien
                }
                return true;
            }
        });

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("ar"));
                arabicAvailable = result != TextToSpeech.LANG_MISSING_DATA
                        && result != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(0.8f);
                ttsReady = true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidTTS");

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }
    }

    /** Fonctions accessibles depuis le JavaScript du jeu (window.AndroidTTS). */
    private class Bridge {
        @JavascriptInterface
        public boolean ready() {
            return ttsReady;
        }

        @JavascriptInterface
        public boolean hasArabic() {
            return ttsReady && arabicAvailable;
        }

        @JavascriptInterface
        public boolean speak(String text) {
            if (!ttsReady || !arabicAvailable || text == null) return false;
            return tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "voyage") == TextToSpeech.SUCCESS;
        }

        @JavascriptInterface
        public void openTtsSettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA));
                    } catch (Exception ignored) {
                        // réglage introuvable sur ce téléphone
                    }
                }
            });
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        // Le bouton « retour » d'Android revient à l'écran précédent du jeu.
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
