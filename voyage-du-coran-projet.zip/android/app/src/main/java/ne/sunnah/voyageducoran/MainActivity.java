package ne.sunnah.voyageducoran;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.Locale;

/**
 * Le Voyage du Coran — écran unique de l'application Android.
 *
 * L'application affiche le jeu web (dossier assets/www, copié depuis la racine du dépôt)
 * dans une WebView. Les fichiers sont servis depuis le téléphone lui-même :
 * aucune connexion Internet n'est utilisée.
 *
 * Le jeu web appelle « AndroidTTS » pour faire lire l'arabe par la synthèse vocale
 * du téléphone, car la voix du navigateur n'existe pas dans une WebView.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/www/index.html";

    private static final String GOOGLE_TTS = "com.google.android.tts";

    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile boolean arabicAvailable = false;
    private volatile String engineName = "aucun";
    private volatile int languageCode = -99;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);              // progression et réglages (localStorage)
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (HOST.equals(url.getHost())) return false;   // page du jeu : on reste dans l'application
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, url));   // lien externe : navigateur du téléphone
                } catch (Exception ignored) {
                    // aucun navigateur : on ignore le lien
                }
                return true;
            }
        });

        startTts(isInstalled(GOOGLE_TTS));

        web.addJavascriptInterface(new Bridge(), "AndroidTTS");

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }
    }

    /** Vrai si l'application indiquée est installée sur le téléphone. */
    private boolean isInstalled(String packageName) {
        try {
            getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Démarre la synthèse vocale. On préfère le moteur Google, qui propose l'arabe
     * gratuitement, même si le téléphone utilise un autre moteur par défaut (Xiaomi, Samsung…).
     */
    private void startTts(final boolean preferGoogle) {
        TextToSpeech.OnInitListener listener = status -> {
            if (status == TextToSpeech.SUCCESS) {
                engineName = preferGoogle ? GOOGLE_TTS : String.valueOf(tts.getDefaultEngine());
                tts.setSpeechRate(0.8f);
                ttsReady = true;
                checkArabic();
            } else if (preferGoogle) {
                startTts(false);   // le moteur Google n'a pas démarré : on essaie celui du téléphone
            }
        };
        tts = preferGoogle ? new TextToSpeech(this, listener, GOOGLE_TTS) : new TextToSpeech(this, listener);
    }

    /** Vérifie (ou revérifie) que la voix arabe est disponible. */
    private synchronized void checkArabic() {
        if (!ttsReady) return;
        Locale[] candidates = { new Locale("ar"), new Locale("ar", "SA"), new Locale("ar", "EG") };
        for (Locale locale : candidates) {
            int result = tts.setLanguage(locale);
            languageCode = result;
            if (result >= TextToSpeech.LANG_AVAILABLE) {
                arabicAvailable = true;
                return;
            }
        }
        arabicAvailable = false;
    }

    /** Fonctions accessibles depuis le JavaScript du jeu (window.AndroidTTS). */
    private class Bridge {
        @JavascriptInterface
        public boolean ready() {
            return ttsReady;
        }

        @JavascriptInterface
        public boolean hasArabic() {
            return ttsReady && arabicAvailable;
        }

        @JavascriptInterface
        public String status() {
            String langue;
            if (!ttsReady) langue = "synthèse vocale pas encore prête";
            else if (arabicAvailable) langue = "voix arabe disponible";
            else if (languageCode == TextToSpeech.LANG_MISSING_DATA) langue = "voix arabe à télécharger";
            else langue = "arabe non pris en charge par ce moteur";
            return "Moteur : " + engineName + " · " + langue + " (code " + languageCode + ")";
        }

        @JavascriptInterface
        public boolean speak(String text) {
            if (!arabicAvailable) checkArabic();   // la voix a peut-être été installée entre-temps
            if (!ttsReady || !arabicAvailable || text == null) return false;
            return tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "voyage") == TextToSpeech.SUCCESS;
        }

        @JavascriptInterface
        public void openTtsSettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA));
                    } catch (Exception ignored) {
                        // réglage introuvable sur ce téléphone
                    }
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkArabic();   // au retour des réglages du téléphone
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        // Le bouton « retour » d'Android revient à l'écran précédent du jeu.
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
