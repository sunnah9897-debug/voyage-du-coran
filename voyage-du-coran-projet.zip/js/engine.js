/*
 * Le Voyage du Coran — moteur du jeu (logique pure, sans affichage).
 *
 * Ce fichier ne touche ni à l'écran ni au stockage : il reçoit des données
 * et renvoie des résultats. Cela permet de le tester automatiquement
 * (tests/engine.test.js) et de le réutiliser plus tard dans une application
 * Android.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();           // Node.js (tests)
  } else {
    root.Engine = factory();              // Navigateur
  }
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  var PROGRESS_VERSION = 1;
  var QUIZ_POINTS_PER_ANSWER = 5;
  var GAME_IDS = ["images", "memory", "trace", "spell"];
  var GAME_POINTS_PER_ANSWER = 5;
  var QUESTION_TYPES = ["letterToName", "nameToLetter", "soundToLetter",
    "formToLetter", "dots", "nonConnecting", "order"];

  /* ---------- Vérification du contenu ---------- */

  // Renvoie la liste des erreurs trouvées dans les fichiers de contenu.
  // Une liste vide signifie que le contenu est cohérent.
  function validateContent(lettersData, exercisesData) {
    var errors = [];
    if (!lettersData || !Array.isArray(lettersData.letters)) {
      return ["arabic-letters.json : liste « letters » manquante"];
    }
    if (!exercisesData || !Array.isArray(exercisesData.exercises)) {
      return ["exercises.json : liste « exercises » manquante"];
    }
    var ids = {};
    lettersData.letters.forEach(function (l, i) {
      if (!l.id || !l.char || !l.nameFr || !l.forms) {
        errors.push("Lettre n°" + (i + 1) + " incomplète");
      }
      if (ids[l.id]) errors.push("Identifiant de lettre en double : " + l.id);
      ids[l.id] = true;
    });
    var qids = {};
    exercisesData.exercises.forEach(function (ex) {
      if (!Array.isArray(ex.questions) || ex.questions.length === 0) {
        errors.push(ex.id + " : aucune question");
        return;
      }
      ex.questions.forEach(function (q) {
        var where = ex.id + "/" + q.id;
        if (qids[q.id]) errors.push(where + " : identifiant en double");
        qids[q.id] = true;
        if (QUESTION_TYPES.indexOf(q.type) < 0) {
          errors.push(where + " : type inconnu « " + q.type + " »");
          return;
        }
        if (!Array.isArray(q.choices) || q.choices.length < 2) {
          errors.push(where + " : il faut au moins 2 choix");
          return;
        }
        if (q.type === "dots") {
          if (!ids[q.letter]) errors.push(where + " : lettre inconnue");
          var letter = lettersData.letters.filter(function (l) { return l.id === q.letter; })[0];
          if (letter && letter.dots !== q.answer) errors.push(where + " : nombre de points faux");
          if (q.choices.indexOf(q.answer) < 0) errors.push(where + " : réponse absente des choix");
          return;
        }
        q.choices.forEach(function (c) {
          if (!ids[c]) errors.push(where + " : choix inconnu « " + c + " »");
        });
        if (q.type === "order") {
          var sorted = q.choices.slice().sort(function (a, b) {
            return orderOf(lettersData, a) - orderOf(lettersData, b);
          });
          if (JSON.stringify(sorted) !== JSON.stringify(q.answer)) {
            errors.push(where + " : ordre de réponse incorrect");
          }
          return;
        }
        if (q.choices.indexOf(q.answer) < 0) errors.push(where + " : réponse absente des choix");
        if (q.type === "nonConnecting") {
          q.choices.forEach(function (c) {
            var l = findLetter(lettersData, c);
            var shouldBeAnswer = l && l.connectsToNext === false;
            if (shouldBeAnswer !== (c === q.answer)) {
              errors.push(where + " : ambiguïté sur la lettre « " + c + " »");
            }
          });
        } else if (q.letter !== q.answer) {
          errors.push(where + " : la réponse doit être la lettre montrée");
        }
        if (q.type === "formToLetter" && ["initial", "medial", "final"].indexOf(q.form) < 0) {
          errors.push(where + " : forme inconnue");
        }
      });
    });
    return errors;
  }

  // Retire les voyelles et signes (harakât, shadda, soukoun) d'un mot arabe.
  function stripHarakat(text) {
    return String(text).replace(/[\u064B-\u0652\u0670]/g, "");
  }
  // Alif portant une hamza (أ إ آ) compte comme alif pour la première lettre.
  function baseLetter(ch) { return /[\u0622\u0623\u0625]/.test(ch) ? "\u0627" : ch; }

  // Vérifie les mots illustrés : un mot par lettre, qui commence bien par cette lettre,
  // et dont l'épellation (si présente) redonne exactement le mot.
  function validateWords(lettersData, wordsData) {
    var errors = [];
    if (!wordsData || !Array.isArray(wordsData.words)) return ["words.json : liste « words » manquante"];
    var seenLetter = {}, seenId = {};
    wordsData.words.forEach(function (w, i) {
      var where = "Mot n°" + (i + 1) + " (" + (w && w.id) + ")";
      if (!w || !w.id || !w.word || !w.fr || !w.emoji || !w.letter) { errors.push(where + " incomplet"); return; }
      if (seenId[w.id]) errors.push(where + " : identifiant en double");
      seenId[w.id] = true;
      var l = findLetter(lettersData, w.letter);
      if (!l) { errors.push(where + " : lettre inconnue"); return; }
      if (seenLetter[w.letter]) errors.push(where + " : deux mots pour la même lettre");
      seenLetter[w.letter] = true;
      var plain = stripHarakat(w.word);
      if (baseLetter(plain.charAt(0)) !== l.char) errors.push(where + " : ne commence pas par " + l.nameFr);
      if (w.spell) {
        var joined = w.spell.map(function (id) { var x = findLetter(lettersData, id); return x ? x.char : "?"; }).join("");
        if (joined !== plain) errors.push(where + " : épellation différente du mot");
      }
    });
    lettersData.letters.forEach(function (l) {
      if (!seenLetter[l.id]) errors.push("Aucun mot pour la lettre " + l.nameFr);
    });
    return errors;
  }

  function findLetter(lettersData, id) {
    return lettersData.letters.filter(function (l) { return l.id === id; })[0];
  }
  function orderOf(lettersData, id) {
    var l = findLetter(lettersData, id);
    return l ? l.order : 999;
  }

  /* ---------- Correction ---------- */

  // Vrai si la réponse donnée est juste. Pour « order », answer est une liste.
  function isCorrect(question, given) {
    if (!question) return false;
    if (question.type === "order") {
      return Array.isArray(given) && given.length === question.answer.length &&
        given.every(function (v, i) { return v === question.answer[i]; });
    }
    return given === question.answer;
  }

  /* ---------- Progression ---------- */

  function newProgress() {
    return { version: PROGRESS_VERSION, exercises: {}, quiz: { best: 0, total: 0, attempts: 0 }, games: {} };
  }

  function toCount(v) {
    var n = Number(v);
    return Number.isFinite(n) && n >= 0 ? Math.floor(n) : 0;
  }

  // Lit la progression enregistrée (texte JSON) et la nettoie.
  // Toute donnée invalide ou trafiquée est ignorée : on repart de zéro
  // pour l'élément concerné plutôt que de planter.
  function loadProgress(raw, exercisesData) {
    var p = newProgress();
    var data;
    try { data = JSON.parse(raw); } catch (e) { return p; }
    if (!data || typeof data !== "object" || data.version !== PROGRESS_VERSION) return p;
    var known = {};
    if (exercisesData) {
      exercisesData.exercises.forEach(function (ex) { known[ex.id] = ex.questions.length; });
    }
    var exs = data.exercises && typeof data.exercises === "object" ? data.exercises : {};
    Object.keys(exs).forEach(function (id) {
      if (exercisesData && !(id in known)) return;
      var total = exercisesData ? known[id] : toCount(exs[id].total);
      var best = Math.min(toCount(exs[id] && exs[id].best), total);
      p.exercises[id] = { best: best, total: total, attempts: toCount(exs[id] && exs[id].attempts) };
    });
    var games = data.games && typeof data.games === "object" ? data.games : {};
    GAME_IDS.forEach(function (id) {
      var g = games[id];
      if (!g || typeof g !== "object") return;
      var gt = toCount(g.total);
      p.games[id] = { best: Math.min(toCount(g.best), gt), total: gt, attempts: toCount(g.attempts) };
    });
    if (data.quiz && typeof data.quiz === "object") {
      var qt = toCount(data.quiz.total);
      p.quiz = { best: Math.min(toCount(data.quiz.best), qt), total: qt, attempts: toCount(data.quiz.attempts) };
    }
    return p;
  }

  // Enregistre le résultat d'un exercice. On garde le meilleur score :
  // refaire un exercice ne fait jamais perdre de points.
  function recordExercise(progress, exerciseId, correct, total) {
    var prev = progress.exercises[exerciseId] || { best: 0, total: total, attempts: 0 };
    progress.exercises[exerciseId] = {
      best: Math.max(prev.best, Math.min(correct, total)),
      total: total,
      attempts: prev.attempts + 1
    };
    return progress;
  }

  function recordQuiz(progress, correct, total) {
    var prev = progress.quiz || { best: 0, total: total, attempts: 0 };
    progress.quiz = { best: Math.max(prev.best, Math.min(correct, total)), total: total, attempts: prev.attempts + 1 };
    return progress;
  }

  function recordGame(progress, gameId, correct, total) {
    if (GAME_IDS.indexOf(gameId) < 0) return progress;
    progress.games = progress.games || {};
    var prev = progress.games[gameId] || { best: 0, total: total, attempts: 0 };
    progress.games[gameId] = { best: Math.max(prev.best, Math.min(correct, total)), total: total, attempts: prev.attempts + 1 };
    return progress;
  }

  function isPassed(entry, passRatio) {
    return !!entry && entry.total > 0 && entry.best / entry.total >= passRatio;
  }

  // Les points sont recalculés à partir des meilleurs scores :
  // 10 points par bonne réponse (meilleure tentative) + 5 par bonne réponse au quiz.
  // Ils ne peuvent donc pas être « gonflés » en rejouant le même exercice.
  function totalPoints(progress, pointsPerAnswer) {
    var pts = 0;
    Object.keys(progress.exercises).forEach(function (id) {
      pts += progress.exercises[id].best * pointsPerAnswer;
    });
    pts += (progress.quiz ? progress.quiz.best : 0) * QUIZ_POINTS_PER_ANSWER;
    var games = progress.games || {};
    Object.keys(games).forEach(function (id) { pts += games[id].best * GAME_POINTS_PER_ANSWER; });
    return pts;
  }

  // Étoiles d'un exercice (0 à 3) d'après le meilleur score :
  // 3 = sans faute, 2 = réussi, 1 = au moins la moitié, 0 = pas encore.
  function stars(entry, passRatio) {
    if (!entry || !entry.total) return 0;
    var r = entry.best / entry.total;
    if (r >= 1) return 3;
    if (r >= passRatio) return 2;
    if (r >= 0.5) return 1;
    return 0;
  }

  function countPassed(progress, passRatio) {
    return Object.keys(progress.exercises).filter(function (id) {
      return isPassed(progress.exercises[id], passRatio);
    }).length;
  }

  // Liste des badges, avec indication de ceux qui sont obtenus.
  function badges(progress, exercisesData) {
    var ratio = exercisesData.meta.passRatio;
    var passed = countPassed(progress, ratio);
    var all = exercisesData.exercises.length;
    var perfect = Object.keys(progress.exercises).some(function (id) {
      var e = progress.exercises[id];
      return e.total > 0 && e.best === e.total;
    });
    var levelsDone = exercisesData.levels.filter(function (lv) {
      var exs = exercisesData.exercises.filter(function (e) { return e.level === lv.level; });
      return exs.every(function (e) { return isPassed(progress.exercises[e.id], ratio); });
    }).length;
    return [
      { id: "first", title: "Premier pas", desc: "Réussir un premier exercice", earned: passed >= 1 },
      { id: "level", title: "Niveau franchi", desc: "Réussir tous les exercices d'un niveau", earned: levelsDone >= 1 },
      { id: "perfect", title: "Sans faute", desc: "Obtenir toutes les bonnes réponses à un exercice", earned: perfect },
      { id: "five", title: "Persévérance", desc: "Réussir 5 exercices", earned: passed >= 5 },
      { id: "quiz", title: "Quiz réussi", desc: "Obtenir au moins 8/10 au quiz", earned: progress.quiz.total > 0 && progress.quiz.best >= Math.ceil(progress.quiz.total * 0.8) },
      { id: "explorer", title: "Explorateur", desc: "Jouer aux 4 jeux", earned: GAME_IDS.every(function (g) { return progress.games && progress.games[g] && progress.games[g].attempts > 0; }) },
      { id: "all", title: "Alphabet maîtrisé", desc: "Réussir les " + all + " exercices", earned: passed === all }
    ];
  }

  /* ---------- Quiz ---------- */

  // Tire « count » questions différentes parmi tous les exercices.
  // « random » peut être remplacé dans les tests pour obtenir un tirage fixe.
  function buildQuiz(exercisesData, count, random) {
    random = random || Math.random;
    var pool = [];
    exercisesData.exercises.forEach(function (ex) {
      ex.questions.forEach(function (q) { pool.push(q); });
    });
    for (var i = pool.length - 1; i > 0; i--) {
      var j = Math.floor(random() * (i + 1));
      var t = pool[i]; pool[i] = pool[j]; pool[j] = t;
    }
    return pool.slice(0, Math.min(count, pool.length));
  }

  // Mélange les choix affichés (sans modifier la question d'origine).
  function shuffled(list, random) {
    random = random || Math.random;
    var a = list.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  /* ---------- Jeux ---------- */

  // Jeu de mémoire : « pairs » paires (lettre ↔ image du mot), mélangées.
  function buildMemoryDeck(wordsData, pairs, random) {
    var chosen = shuffled(wordsData.words, random).slice(0, pairs);
    var deck = [];
    chosen.forEach(function (w) {
      deck.push({ pair: w.id, kind: "letter", letter: w.letter });
      deck.push({ pair: w.id, kind: "image", word: w.id });
    });
    return shuffled(deck, random);
  }

  // Tracé : compare la lettre (mask) et ce que l'enfant a dessiné (ink).
  // Deux tableaux de même taille, 1 = pixel rempli. Renvoie :
  //   coverage = part de la lettre recouverte ; spill = part du tracé hors de la lettre.
  //   zone (facultatif) = la lettre élargie : un trait proche de la lettre n'est pas compté comme débordement.
  function traceScore(mask, ink, zone) {
    zone = zone || mask;
    var letter = 0, covered = 0, drawn = 0, outside = 0;
    for (var i = 0; i < mask.length; i++) {
      if (mask[i]) { letter++; if (ink[i]) covered++; }
      if (ink[i]) { drawn++; if (!zone[i]) outside++; }
    }
    return { coverage: letter ? covered / letter : 0, spill: drawn ? outside / drawn : 0, drawn: drawn };
  }
  // Élargit une forme (grille carrée de côté « size ») de « radius » cases dans toutes les directions.
  function dilate(mask, size, radius) {
    var out = new Array(mask.length);
    for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) {
      var v = 0;
      for (var dy = -radius; dy <= radius && !v; dy++) for (var dx = -radius; dx <= radius && !v; dx++) {
        var xx = x + dx, yy = y + dy;
        if (xx >= 0 && yy >= 0 && xx < size && yy < size && mask[yy * size + xx]) v = 1;
      }
      out[y * size + x] = v;
    }
    return out;
  }
  function tracePassed(score) { return score.coverage >= 0.55 && score.spill <= 0.45; }

  return {
    GAME_IDS: GAME_IDS,
    GAME_POINTS_PER_ANSWER: GAME_POINTS_PER_ANSWER,
    stripHarakat: stripHarakat,
    validateWords: validateWords,
    recordGame: recordGame,
    buildMemoryDeck: buildMemoryDeck,
    traceScore: traceScore,
    dilate: dilate,
    tracePassed: tracePassed,
    validateContent: validateContent,
    isCorrect: isCorrect,
    newProgress: newProgress,
    loadProgress: loadProgress,
    recordExercise: recordExercise,
    recordQuiz: recordQuiz,
    isPassed: isPassed,
    stars: stars,
    totalPoints: totalPoints,
    countPassed: countPassed,
    badges: badges,
    buildQuiz: buildQuiz,
    shuffled: shuffled,
    QUIZ_POINTS_PER_ANSWER: QUIZ_POINTS_PER_ANSWER
  };
});
