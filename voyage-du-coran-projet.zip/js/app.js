/*
 * Le Voyage du Coran — affichage et navigation (v0.2).
 *
 * Les écrans sont choisis d'après l'adresse (#/accueil, #/parcours, …),
 * ce qui fait fonctionner le bouton « retour » d'Android.
 * Aucun texte venant des fichiers de contenu n'est inséré avec innerHTML :
 * tout passe par textContent, pour éviter les injections de code.
 * Seules les icônes (constantes écrites ici) passent par un modèle HTML.
 */
(function () {
  "use strict";

  var STORAGE_KEY = "vdc.progress.v1";
  var SETTINGS_KEY = "vdc.settings.v1";
  var QUIZ_SIZE = 10;
  var QUIZ_PASS = 0.8;
  var FORM_LABELS = { isolated: "isolée", initial: "début", medial: "milieu", final: "fin" };
  var FORM_PHRASE = { initial: "au début d'un mot", medial: "au milieu d'un mot", final: "à la fin d'un mot" };
  var NODE_X = [50, 74, 50, 26];   // position horizontale des étapes sur le chemin (%)
  var NODE_GAP = 108;              // espace vertical entre deux étapes (px)
  var PATH_TOP = 40;               // place réservée au-dessus de la première étape (bulle)

  var state = {
    letters: null, exercises: null, words: null, audio: null, byId: {}, wordByLetter: {}, wordById: {},
    progress: null, storageOk: true,
    settings: { sound: true, vibrate: true, theme: "auto", textLarge: false, mode: null },
    session: null, lastResult: null
  };
  var screen = document.getElementById("screen");

  /* ---------- Icônes (constantes) ---------- */
  var ICONS = {
    star: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2.5l2.9 6 6.6.8-4.9 4.5 1.3 6.5L12 17l-5.9 3.3 1.3-6.5L2.5 9.3l6.6-.8z"/></svg>',
    close: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    back: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>',
    chev: '<svg class="chev" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
    check: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10" stroke-width="2"/><path d="M7.5 12.5l3 3 6-6.5"/></svg>',
    cross: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10" stroke-width="2"/><path d="M9 9l6 6M15 9l-6 6"/></svg>',
    flame: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2c1 3.5 5 5.5 5 10.5A5 5 0 0 1 7 12.5c0-2 1-3.5 2-4.5.3 1.6 1.2 2.6 2.2 3C10.6 8 11 5 12 2z"/></svg>',
    info: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7.5v.5"/></svg>',
    ear: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9a6 6 0 1 1 12 0c0 3-2 4-3 5.5S14 18 12 19.5 8 20 8 18"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 1.5-1.5 2-1.5 3"/></svg>',
    map: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h7.5a3.5 3.5 0 0 0 0-7h-7a3.5 3.5 0 0 1 0-7H16"/></svg>',
    book: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 21V5M19 19v2H6"/></svg>',
    bolt: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg>',
    heart: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20s-7-4.3-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.7-7 10-7 10z"/></svg>',
    flag: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V4M5 4h11l-2 4 2 4H5"/></svg>',
    target: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/></svg>',
    mountain: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M2 20 9 8l4 6 3-4 6 10z"/></svg>',
    crown: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/></svg>',
    trophy: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/></svg>',
    pattern: '<svg aria-hidden="true"><defs><pattern id="vdc-stars" width="56" height="56" patternUnits="userSpaceOnUse"><g transform="translate(28 28)" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="-13" y="-13" width="26" height="26"/><rect x="-13" y="-13" width="26" height="26" transform="rotate(45)"/><circle r="5"/></g><path d="M0 0h6M50 0h6M0 56h6M50 56h6" stroke="currentColor"/></pattern></defs><rect width="100%" height="100%" fill="url(#vdc-stars)"/></svg>',
    moon: '<svg class="sky-moon" viewBox="0 0 120 120" aria-hidden="true"><defs><mask id="vdc-moon"><rect width="120" height="120" fill="#fff"/><circle cx="76" cy="46" r="34" fill="#000"/></mask></defs><circle cx="58" cy="58" r="36" fill="#f1dfb0" mask="url(#vdc-moon)"/><path fill="#f1dfb0" d="M96 82l2 4.5 4.8.6-3.6 3.3 1 4.8-4.2-2.4-4.2 2.4 1-4.8-3.6-3.3 4.8-.6z"/></svg>',
    mascot: '<svg viewBox="0 0 120 120" aria-hidden="true"> <ellipse cx="60" cy="112" rx="40" ry="5" fill="#000" opacity=".12"/> <path d="M24 74c-6 2-9 8-8 14" fill="none" stroke="#c98a42" stroke-width="4" stroke-linecap="round"/> <rect x="32" y="84" width="8" height="25" rx="4" fill="#c98a42"/> <rect x="44" y="86" width="8" height="24" rx="4" fill="#d9984d"/> <rect x="66" y="86" width="8" height="24" rx="4" fill="#d9984d"/> <rect x="78" y="84" width="8" height="25" rx="4" fill="#c98a42"/> <ellipse cx="57" cy="78" rx="34" ry="17" fill="#e8ad62"/> <path d="M33 70c2-22 12-32 24-32s22 10 24 32z" fill="#e8ad62"/> <path d="M38 66c3-14 10-21 19-21s16 7 19 21z" fill="#0e6650"/> <path d="M41 62h32" stroke="#e9c46a" stroke-width="3" stroke-linecap="round"/> <circle cx="57" cy="52" r="3" fill="#e9c46a"/> <path d="M84 74c8-8 9-20 11-32" fill="none" stroke="#e8ad62" stroke-width="14" stroke-linecap="round"/> <ellipse cx="91" cy="20" rx="3.5" ry="7" fill="#c98a42" transform="rotate(-20 91 20)"/> <ellipse cx="99" cy="33" rx="15" ry="13" fill="#e8ad62"/> <ellipse cx="110" cy="38" rx="8.5" ry="7.5" fill="#f3c98f"/> <circle cx="113" cy="35" r="1.4" fill="#7a4a1c"/> <circle cx="98" cy="29" r="3.6" fill="#2b2118"/> <circle cx="99.2" cy="27.8" r="1.2" fill="#fff"/> <path d="M93 24.5c2-2 5-2.4 7.5-1.4" fill="none" stroke="#7a4a1c" stroke-width="1.6" stroke-linecap="round"/> <circle cx="102" cy="38" r="3.2" fill="#f39b8a" opacity=".7"/> <path d="M106 42.5c2.5 2 5.5 2 8 .3" fill="none" stroke="#7a4a1c" stroke-width="1.8" stroke-linecap="round"/> </svg>',
    sun: '<svg class="sky-sun" viewBox="0 0 64 64" aria-hidden="true"><g stroke="#ffb31f" stroke-width="4" stroke-linecap="round"><path d="M32 4v7M32 53v7M4 32h7M53 32h7M12 12l5 5M47 47l5 5M12 52l5-5M47 17l5-5"/></g><circle cx="32" cy="32" r="14" fill="#ffc93c"/></svg>',
    dunes: '<svg viewBox="0 0 400 70" preserveAspectRatio="none" aria-hidden="true"><path d="M0 40C60 18 120 22 180 38S300 62 400 30V70H0z" fill="#f7d58e"/><path d="M0 56C80 40 160 44 240 56S350 66 400 52V70H0z" fill="#efc06a"/></svg>',
    speaker: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/></svg>',
    puzzle: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="7" width="19" height="11" rx="5.5"/><path d="M7.5 10.5v4M5.5 12.5h4"/><circle cx="15.5" cy="11.5" r=".6" fill="currentColor"/><circle cx="17.5" cy="13.8" r=".6" fill="currentColor"/></svg>',
    crescent: '<svg viewBox="0 0 84 84" aria-hidden="true"><defs><mask id="vdc-cres"><rect width="84" height="84" fill="#fff"/><circle cx="52" cy="34" r="24" fill="#000"/></mask></defs><circle cx="40" cy="42" r="26" fill="#f1dfb0" mask="url(#vdc-cres)"/><g transform="translate(64 58)" fill="#c2932f"><rect x="-7" y="-7" width="14" height="14" rx="1.5"/><rect x="-7" y="-7" width="14" height="14" rx="1.5" transform="rotate(45)"/></g></svg>',
    frame: '<svg class="frame" viewBox="0 0 200 200" aria-hidden="true"><g transform="translate(100 100)"><g class="outer"><rect x="-70" y="-70" width="140" height="140" rx="10"/></g><g class="outer"><rect x="-70" y="-70" width="140" height="140" rx="10" transform="rotate(45)"/></g><circle class="inner" r="76"/></g></svg>'
  };
  var tpl = document.createElement("template");
  function icon(name) { tpl.innerHTML = ICONS[name]; return tpl.content.firstChild.cloneNode(true); }

  /* ---------- Petits outils d'affichage ---------- */
  function h(tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === "onclick") el.addEventListener("click", v);
        else if (k === "onchange") el.addEventListener("change", v);
        else el.setAttribute(k, v === true ? "" : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) append(el, arguments[i]);
    return el;
  }
  function append(el, child) {
    if (child === null || child === undefined || child === false) return;
    if (Array.isArray(child)) { child.forEach(function (c) { append(el, c); }); return; }
    el.appendChild(typeof child === "string" || typeof child === "number"
      ? document.createTextNode(String(child)) : child);
  }
  function ar(text, cls) {
    return h("span", { "class": "ar" + (cls ? " " + cls : ""), lang: "ar", dir: "rtl" }, text);
  }
  function render(nodes, title, opts) {
    opts = opts || {};
    document.body.classList.toggle("playing", !!opts.playing);
    document.querySelectorAll("canvas.confetti").forEach(function (c) { c.remove(); });
    screen.textContent = "";
    screen.classList.remove("enter");
    void screen.offsetWidth;   // relance l'animation d'entrée
    screen.classList.add("enter");
    append(screen, nodes);
    document.title = (title ? title + " · " : "") + "Le Voyage du Coran";
    window.scrollTo(0, 0);
  }
  function backLink(href, label) {
    return h("a", { "class": "back", href: href }, icon("back"), label);
  }
  function plural(n, one, many) { return n + " " + (n > 1 ? many : one); }
  function dotsText(n) { return n === 0 ? "aucun point" : plural(n, "point", "points"); }

  /* ---------- Réglages ---------- */
  function loadSettings() {
    try {
      var s = JSON.parse(window.localStorage.getItem(SETTINGS_KEY) || "{}");
      if (s && typeof s === "object") {
        if (typeof s.sound === "boolean") state.settings.sound = s.sound;
        if (typeof s.vibrate === "boolean") state.settings.vibrate = s.vibrate;
        if (["auto", "light", "dark"].indexOf(s.theme) >= 0) state.settings.theme = s.theme;
        if (typeof s.textLarge === "boolean") state.settings.textLarge = s.textLarge;
        if (s.mode === "kid" || s.mode === "adult") state.settings.mode = s.mode;
      }
    } catch (e) { /* réglages par défaut */ }
    applySettings();
  }
  function saveSettings() {
    try { window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(state.settings)); } catch (e) { /* ignoré */ }
    applySettings();
  }
  function applySettings() {
    var root = document.documentElement;
    if (state.settings.theme === "auto") root.removeAttribute("data-theme");
    else root.setAttribute("data-theme", state.settings.theme);
    root.classList.toggle("text-large", state.settings.textLarge);
    if (state.settings.mode) root.setAttribute("data-mode", state.settings.mode); else root.removeAttribute("data-mode");
  }

  /* ---------- Sons (fabriqués par le navigateur, aucun fichier audio) ---------- */
  var audioCtx = null;
  function tone(freq, start, dur, type, vol) {
    var t = audioCtx.currentTime + start;
    var o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.type = type || "sine"; o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol || 0.18, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(audioCtx.destination);
    o.start(t); o.stop(t + dur + 0.02);
  }
  function play(kind) {
    if (!state.settings.sound) return;
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === "suspended") audioCtx.resume();
      if (kind === "ok") { tone(784, 0, 0.12); tone(1175, 0.09, 0.22); }
      else if (kind === "ko") { tone(220, 0, 0.22, "triangle", 0.14); tone(185, 0.12, 0.25, "triangle", 0.12); }
      else if (kind === "win") { [523, 659, 784, 1047].forEach(function (f, i) { tone(f, i * 0.11, 0.3); }); }
      else if (kind === "tap") { tone(660, 0, 0.06, "sine", 0.08); }
    } catch (e) { /* pas de son disponible */ }
  }
  function buzz(ms) {
    if (state.settings.vibrate && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) { /* ignoré */ } }
  }

  /* ---------- Message temporaire ---------- */
  var toastTimer = null;
  function toast(text) {
    var old = document.querySelector(".toast");
    if (old) old.remove();
    var t = h("div", { "class": "toast", role: "status" }, text);
    document.body.appendChild(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.remove(); }, 4200);
  }

  /* ---------- Écoute : enregistrement réel si disponible, sinon voix du téléphone ---------- */
  var voiceWarned = false;
  function arabicVoice() {
    if (!("speechSynthesis" in window)) return null;
    var voices = window.speechSynthesis.getVoices() || [];
    return voices.filter(function (v) { return /^ar/i.test(v.lang); })[0] || null;
  }
  if ("speechSynthesis" in window) { try { window.speechSynthesis.getVoices(); } catch (e) { /* ignoré */ } }
  // kind = "letters" ou "words" ; id = identifiant ; text = texte arabe à lire.
  // quiet = lecture automatique (pas demandée par l'utilisateur) : aucun message en cas d'échec.
  function speak(text, kind, id, btn, quiet) {
    var rec = state.audio && state.audio[kind] && state.audio[kind][id];
    if (btn) { btn.classList.add("speaking"); setTimeout(function () { btn.classList.remove("speaking"); }, 1200); }
    if (rec) {
      try { var a = new Audio(rec); a.play().catch(function () { synth(text, quiet); }); return; } catch (e) { /* voix de synthèse */ }
    }
    synth(text, quiet);
  }
  var errorWarned = false;
  function warnOnce(msg, quiet) { if (quiet || errorWarned) return; errorWarned = true; toast(msg); }
  // Dans l'application Android, la voix passe par le pont « AndroidTTS » (voir MainActivity.java).
  var NATIVE = typeof window.AndroidTTS === "object" && window.AndroidTTS !== null;
  function hasArabicVoice() {
    if (NATIVE) { try { return !!window.AndroidTTS.hasArabic(); } catch (e) { return false; } }
    return !!arabicVoice();
  }
  function synth(text, quiet) {
    if (NATIVE) {
      var said = false;
      try { said = window.AndroidTTS.speak(String(text)); } catch (e) { said = false; }
      // Appui volontaire sur le haut-parleur : on prévient à chaque fois ; lecture automatique : jamais.
      if (!said && !quiet) toast("Pas de voix arabe sur ce téléphone. Va dans Paramètres du jeu › Voix › « Installer la voix arabe ».");
      return;
    }
    if (!("speechSynthesis" in window) || typeof window.SpeechSynthesisUtterance !== "function") {
      warnOnce("La lecture à voix haute n'est pas disponible sur cet appareil.", quiet);
      return;
    }
    try {
      var synthApi = window.speechSynthesis;
      synthApi.cancel();
      var u = new window.SpeechSynthesisUtterance(text);
      var v = arabicVoice();
      u.lang = v ? v.lang : "ar-SA";
      if (v) u.voice = v;
      u.rate = 0.75;
      u.onerror = function () { warnOnce("Le téléphone n'a pas pu lire ce mot. Vérifie que la voix arabe est installée (Paramètres du téléphone › Synthèse vocale).", quiet); };
      synthApi.speak(u);
      if (!v && !voiceWarned && !quiet) {
        voiceWarned = true;
        toast("Si tu n'entends rien : installe la voix arabe du téléphone (Paramètres › Synthèse vocale › Arabe).");
      }
    } catch (e) { warnOnce("La lecture à voix haute n'a pas fonctionné.", quiet); }
  }
  function speakBtn(text, kind, id, label, small) {
    var b = h("button", { type: "button", "class": "speak" + (small ? " small" : ""), "aria-label": label || "Écouter" }, icon("speaker"));
    b.addEventListener("click", function (ev) { ev.stopPropagation(); speak(text, kind, id, b); });
    return b;
  }
  function mascot(cls) { return h("span", { "class": "mascot" + (cls ? " " + cls : "") }, icon("mascot")); }
  function isKid() { return state.settings.mode === "kid"; }

  /* ---------- Confettis ---------- */
  function confetti() {
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    var c = h("canvas", { "class": "confetti", "aria-hidden": "true" });
    document.body.appendChild(c);
    var dpr = window.devicePixelRatio || 1;
    var W = c.width = window.innerWidth * dpr, H = c.height = window.innerHeight * dpr;
    var ctx = c.getContext("2d");
    var colors = ["#c2932f", "#e9c46a", "#0e6650", "#2fa383", "#f1dfb0", "#102a43"];
    var parts = [];
    for (var i = 0; i < 110; i++) {
      parts.push({ x: W / 2 + (Math.random() - .5) * W * .3, y: H * .35, vx: (Math.random() - .5) * 14 * dpr,
        vy: (-Math.random() * 14 - 5) * dpr, s: (5 + Math.random() * 6) * dpr, r: Math.random() * 6,
        vr: (Math.random() - .5) * .3, c: colors[i % colors.length] });
    }
    var start = performance.now();
    (function frame(now) {
      var t = now - start;
      ctx.clearRect(0, 0, W, H);
      parts.forEach(function (p) {
        p.vy += 0.45 * dpr; p.x += p.vx; p.y += p.vy; p.vx *= 0.99; p.r += p.vr;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r);
        ctx.globalAlpha = Math.max(0, 1 - t / 2200);
        ctx.fillStyle = p.c; ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2);
        ctx.restore();
      });
      if (t < 2200 && c.isConnected) requestAnimationFrame(frame); else c.remove();
    })(start);
  }

  /* ---------- Progression ---------- */
  function loadProgress() {
    var raw = null;
    try { raw = window.localStorage.getItem(STORAGE_KEY); } catch (e) { state.storageOk = false; }
    state.progress = raw ? Engine.loadProgress(raw, state.exercises) : Engine.newProgress();
  }
  function saveProgress() {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state.progress)); state.storageOk = true; }
    catch (e) { state.storageOk = false; }
    updatePoints();
  }
  function points() { return Engine.totalPoints(state.progress, state.exercises.meta.pointsPerCorrectAnswer); }
  function updatePoints() { document.getElementById("points-pill").textContent = points() + " pt"; }
  function ratio() { return state.exercises.meta.passRatio; }
  function nextExercise() {
    return state.exercises.exercises.filter(function (e) {
      return !Engine.isPassed(state.progress.exercises[e.id], ratio());
    })[0] || null;
  }
  function totalStars() {
    return state.exercises.exercises.reduce(function (n, e) {
      return n + Engine.stars(state.progress.exercises[e.id], ratio());
    }, 0);
  }
  function starsRow(n, cls) {
    var row = h("span", { "class": cls || "node-stars", "aria-label": n + " étoile" + (n > 1 ? "s" : "") + " sur 3" });
    for (var i = 0; i < 3; i++) { var s = icon("star"); if (i < n) s.classList.add("on"); row.appendChild(s); }
    return row;
  }

  /* ---------- Écran : accueil ---------- */
  function screenHome() {
    var ex = state.exercises;
    var passed = Engine.countPassed(state.progress, ratio());
    var next = nextExercise();
    var firstLetter = next ? state.byId[next.questions[0].letter || next.questions[0].answer] : null;
    var kid = isKid();
    var sky = h("section", { "class": "sky hero" },
      kid ? [icon("sun"), h("div", { "class": "sky-dunes" }, icon("dunes"))] : [h("div", { "class": "sky-pattern" }, icon("pattern")), icon("moon")],
      h("p", { "class": "eyebrow" }, "Étape 1 du voyage · L'alphabet"),
      h("h1", null, "Le Voyage du Coran"),
      h("p", { "class": "sky-ar", lang: "ar", dir: "rtl" }, "رِحْلَةُ الْقُرْآنِ"),
      h("p", { "class": "lead" }, passed === 0
        ? "Tout voyage commence par une lettre. Découvre les 28 lettres de l'arabe en jouant, à ton rythme."
        : passed === ex.exercises.length
          ? "Mâ châ' Allah, tu as réussi tout le parcours. Révise avec le quiz quand tu veux."
          : "Bon retour ! Tu as déjà réussi " + plural(passed, "exercice", "exercices") + " sur " + ex.exercises.length + "."),
      next
        ? h("a", { "class": "btn gold block", href: "#/jouer/" + next.id }, passed ? "Continuer le voyage" : "Commencer le voyage")
        : h("a", { "class": "btn gold block", href: "#/quiz" }, "Faire le quiz de révision")
    );
    render([
      kid ? h("div", { "class": "say" }, mascot("bounce"),
        h("p", { "class": "bubble-say" }, passed === 0
          ? "Salam ! Moi, c'est Jamal le chameau. On apprend les lettres ensemble ?"
          : "Bon retour ! Tu as déjà " + plural(totalStars(), "étoile", "étoiles") + ". On continue ?")) : null,
      sky,
      next ? h("a", { "class": "continue", href: "#/jouer/" + next.id },
        h("span", { "class": "continue-letter" }, ar(firstLetter ? firstLetter.char : "ا")),
        h("span", { "class": "continue-body" },
          h("span", { "class": "eyebrow" }, "À suivre · exercice " + next.number),
          h("b", null, next.title),
          h("span", { "class": "muted small" }, next.goal)),
        icon("chev")) : null,
      h("div", { "class": "stats" },
        stat(passed + "/" + ex.exercises.length, "exercices réussis"),
        stat(points(), "points"),
        stat(totalStars() + "/" + ex.exercises.length * 3, "étoiles")),
      h("div", { "class": "quick" },
        quick("#/jeux", "puzzle", "Les jeux", "Images, mémoire, tracer, épeler"),
        quick("#/alphabet", "book", "L'alphabet", "28 lettres et leurs mots"),
        quick("#/quiz", "bolt", "Quiz express", "10 questions au hasard"),
        quick("#/a-propos", "heart", "Notre mission", "Sources et vie privée")),
      !state.storageOk ? h("p", { "class": "notice" }, icon("info"), h("span", null, "Ton navigateur ne permet pas d'enregistrer la progression (navigation privée ?). Tu peux jouer, mais tes points ne seront pas conservés.")) : null
    ], "Accueil");
  }
  function stat(value, label) { return h("div", { "class": "stat" }, h("b", null, String(value)), h("span", null, label)); }
  function quick(href, ico, title, sub) { return h("a", { href: href }, icon(ico), h("b", null, title), h("span", null, sub)); }

  /* ---------- Écran : parcours (carte des étapes) ---------- */
  function screenJourney() {
    var ex = state.exercises;
    var next = nextExercise();
    var idx = 0;
    var blocks = ex.levels.map(function (lv) {
      var list = ex.exercises.filter(function (e) { return e.level === lv.level; });
      var done = list.filter(function (e) { return Engine.isPassed(state.progress.exercises[e.id], ratio()); }).length;
      var parts = lv.title.split(" — ");
      var head = h("div", { "class": "stage-head" + (done === list.length ? " done" : "") },
        h("span", { "class": "stage-num" }, String(lv.level)),
        h("span", { "class": "stage-title" }, h("b", null, parts[1] || lv.title), h("span", null, parts[0])),
        h("span", { "class": "stage-count" }, done + "/" + list.length));

      var height = PATH_TOP + list.length * NODE_GAP;
      var path = h("div", { "class": "path" });
      path.style.height = height + "px";
      var pts = list.map(function (e, i) { return { x: NODE_X[(idx + i) % NODE_X.length], y: PATH_TOP + i * NODE_GAP + 34 }; });
      path.appendChild(trail(pts, height, done === list.length));
      list.forEach(function (e, i) {
        var p = state.progress.exercises[e.id];
        var passed = Engine.isPassed(p, ratio());
        var cls = "node" + (passed ? " done" : p ? " started" : "") + (next && next.id === e.id ? " next" : "");
        var node = h("a", { "class": cls, href: "#/jouer/" + e.id, "aria-label": "Exercice " + e.number + " : " + e.title + (passed ? ", réussi" : "") },
          h("span", { "class": "node-disc" }, String(e.number), next && next.id === e.id ? h("span", { "class": "bubble", "aria-hidden": "true" }, p ? "Réessayer" : "À toi !") : null),
          starsRow(Engine.stars(p, ratio())),
          h("span", { "class": "node-label" }, e.title));
        node.style.left = pts[i].x + "%";
        node.style.top = (PATH_TOP + i * NODE_GAP) + "px";
        path.appendChild(node);
      });
      idx += list.length;
      return [head, path];
    });
    render([
      h("div", { "class": "section-head" },
        h("h1", null, "Le parcours"),
        h("span", { "class": "muted small" }, totalStars() + " / " + ex.exercises.length * 3 + " étoiles")),
      h("p", { "class": "muted" }, "Avance d'étape en étape. Tu peux refaire un exercice autant de fois que tu veux : seul ton meilleur score compte."),
      h("div", { "class": "journey" }, blocks)
    ], "Parcours");
  }
  function trail(pts, height, walked) {
    var NS = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(NS, "svg");
    svg.setAttribute("class", "trail");
    svg.setAttribute("viewBox", "0 0 100 " + height);
    svg.setAttribute("preserveAspectRatio", "none");
    svg.setAttribute("aria-hidden", "true");
    var d = "M" + pts[0].x + " " + pts[0].y;
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i], my = (a.y + b.y) / 2;
      d += " C" + a.x + " " + my + " " + b.x + " " + my + " " + b.x + " " + b.y;
    }
    var path = document.createElementNS(NS, "path");
    path.setAttribute("d", d);
    path.setAttribute("vector-effect", "non-scaling-stroke");
    if (walked) path.setAttribute("class", "walked");
    svg.appendChild(path);
    return svg;
  }

  /* ---------- Écran : alphabet ---------- */
  function screenAlphabet() {
    render([
      h("h1", null, "L'alphabet arabe"),
      h("p", { "class": "muted" }, "28 lettres, qui se lisent de droite à gauche. Touche une lettre pour ouvrir sa fiche."),
      h("div", { "class": "letter-grid" },
        state.letters.letters.map(function (l) {
          return h("a", { "class": "letter-tile", href: "#/lettre/" + l.id, "aria-label": "Lettre " + l.order + ", " + l.nameFr },
            h("span", { "class": "num", "aria-hidden": "true" }, String(l.order)),
            isKid() && state.wordByLetter[l.id] ? h("span", { "class": "emo", "aria-hidden": "true" }, state.wordByLetter[l.id].emoji) : null,
            ar(l.char), h("small", null, l.nameFr));
        })),
      h("p", { "class": "notice" }, icon("info"), h("span", null, "Contenu en brouillon : les noms et les prononciations doivent encore être vérifiés par un enseignant. Les prononciations écrites sont des approximations."))
    ], "Alphabet");
  }

  function screenLetter(id) {
    var l = state.byId[id];
    if (!l) return screenNotFound();
    var prev = state.letters.letters[l.order - 2];
    var next = state.letters.letters[l.order];
    var medal = h("div", { "class": "medallion big-letter" }, icon("frame"), ar(l.char));
    render([
      backLink("#/alphabet", "Alphabet"),
      medal,
      h("div", { "class": "letter-name" },
        h("h1", null, l.nameFr),
        ar(l.nameAr)),
      h("div", { "class": "listen-row" }, speakBtn(l.nameAr, "letters", l.id, "Écouter le nom de la lettre"),
        h("span", { "class": "muted" }, state.audio && state.audio.letters[l.id] ? "Écouter (voix enregistrée)" : "Écouter (voix du téléphone, provisoire)")),
      wordCard(state.wordByLetter[l.id]),
      h("div", { "class": "facts" },
        h("div", { "class": "fact" }, h("span", null, "Ordre"), h("b", null, l.order + " / 28")),
        h("div", { "class": "fact" }, h("span", null, "Points"), h("b", null, l.dots === 0 ? "Aucun" : String(l.dots))),
        h("div", { "class": "fact" }, h("span", null, "Se lie après"), h("b", null, l.connectsToNext ? "Oui" : "Jamais"))),
      h("div", { "class": "sound" }, icon("ear"), h("div", null, h("b", null, "Prononciation"), h("p", null, l.sound))),
      h("div", { "class": "section" },
        h("h2", null, "Ses 4 formes"),
        h("p", { "class": "muted small" }, "La forme change selon la place de la lettre dans le mot (de droite à gauche)."),
        h("div", { "class": "forms" },
          ["isolated", "initial", "medial", "final"].map(function (f) {
            return h("div", { "class": "form-box" + (f === "isolated" ? " lead" : "") }, ar(l.forms[f]), h("small", null, FORM_LABELS[f]));
          }))),
      h("p", { "class": "notice" }, icon("info"), h("span", null, "Pour bien prononcer, écoute ton enseignant : une description écrite ne suffit pas.")),
      h("div", { "class": "row" },
        prev ? h("a", { "class": "btn secondary", href: "#/lettre/" + prev.id, "data-nav": "prev" }, "← " + prev.nameFr) : null,
        next ? h("a", { "class": "btn", href: "#/lettre/" + next.id, "data-nav": "next" }, next.nameFr + " →") : null)
    ], l.nameFr);
  }

  function wordCard(w) {
    if (!w) return null;
    return h("div", { "class": "word-card" },
      h("span", { "class": "emoji", "aria-hidden": "true" }, w.emoji),
      h("div", { "class": "word-body" },
        h("span", { "class": "eyebrow" }, "Un mot avec cette lettre"),
        ar(w.word, "word-ar"),
        h("span", { "class": "word-fr" }, w.translit + " · " + w.fr)),
      speakBtn(w.word, "words", w.id, "Écouter le mot " + w.fr));
  }

  /* ---------- Jeu : exercice ou quiz ---------- */
  function startExercise(id) {
    var ex = state.exercises.exercises.filter(function (e) { return e.id === id; })[0];
    if (!ex) return screenNotFound();
    state.session = { kind: "exercise", exercise: ex, questions: ex.questions, index: 0, correct: 0, streak: 0, answered: false };
    screenQuestion();
  }
  function startQuiz() {
    state.session = { kind: "quiz", questions: Engine.buildQuiz(state.exercises, QUIZ_SIZE), index: 0, correct: 0, streak: 0, answered: false };
    screenQuestion();
  }

  function screenQuestion() {
    var s = state.session;
    var q = s.questions[s.index];
    var total = s.questions.length;
    var title = s.kind === "quiz" ? "Quiz express" : "Exercice " + s.exercise.number + " · " + s.exercise.title;
    s.answered = false;
    s.sequence = [];

    var fill = h("div", { "class": "progress-fill" });
    var streak = h("span", { "class": "streak", "aria-label": "Série de bonnes réponses" });
    var body = h("div", { "class": "section" });
    render([
      h("div", { "class": "play-top" },
        h("a", { "class": "icon-btn", href: s.kind === "quiz" ? "#/accueil" : "#/parcours", "aria-label": "Quitter" }, icon("close")),
        h("div", { "class": "progress-track", role: "progressbar", "aria-label": "Question " + (s.index + 1) + " sur " + total,
          "aria-valuemin": "0", "aria-valuemax": String(total), "aria-valuenow": String(s.index) }, fill),
        streak),
      h("div", { "class": "q-head" },
        h("p", { "class": "eyebrow" }, title),
        h("p", { "class": "muted small" }, "Question " + (s.index + 1) + " sur " + total)),
      body,
      h("div", { "class": "sheet-space", "aria-hidden": "true" })
    ], title, { playing: true });
    // La barre avance après l'affichage, pour que l'animation soit visible.
    fill.style.width = (100 * s.index / total) + "%";
    requestAnimationFrame(function () { fill.style.width = (100 * (s.index + 0.35) / total) + "%"; });
    showStreak(streak, s.streak);
    buildQuestion(q, body);
  }
  function showStreak(el, n) {
    el.textContent = "";
    if (n >= 2) { append(el, [icon("flame"), String(n)]); el.title = n + " bonnes réponses d'affilée"; }
  }

  function buildQuestion(q, body) {
    var L = state.byId;
    var target = q.letter ? L[q.letter] : null;
    var choices = Engine.shuffled(q.choices);
    function prompt(text) { return h("h1", { "class": "q-prompt" }, text); }
    function letterChoices() {
      return h("div", { "class": "choices letters" }, choices.map(function (id) {
        return h("button", { type: "button", "class": "choice", "data-value": id, "aria-label": "Lettre " + L[id].nameFr,
          onclick: function (ev) { answer(q, id, body, ev.currentTarget); } }, ar(L[id].char));
      }));
    }
    switch (q.type) {
      case "letterToName":
        append(body, [prompt("Comment s'appelle cette lettre ?"),
          h("div", { "class": "q-visual" }, ar(target.char)),
          h("div", { "class": "choices" }, choices.map(function (id) {
            return h("button", { type: "button", "class": "choice", "data-value": id, onclick: function (ev) { answer(q, id, body, ev.currentTarget); } },
              h("span", null, L[id].nameFr), ar(L[id].nameAr, "sub-ar"));
          }))]);
        break;
      case "nameToLetter":
        append(body, [prompt("Touche la lettre « " + target.nameFr + " »"),
          h("p", { "class": "q-sound" }, ar(target.nameAr)), letterChoices()]);
        break;
      case "soundToLetter":
        append(body, [prompt("Quelle lettre se prononce ainsi ?"),
          h("p", { "class": "q-sound" }, target.sound), letterChoices()]);
        break;
      case "formToLetter":
        append(body, [prompt("Cette lettre est écrite " + FORM_PHRASE[q.form] + ". Laquelle est-ce ?"),
          h("div", { "class": "q-visual" }, ar(target.forms[q.form])), letterChoices()]);
        break;
      case "dots":
        append(body, [prompt("Combien de points porte cette lettre ?"),
          h("div", { "class": "q-visual" }, ar(target.char)),
          h("div", { "class": "choices cols2" }, q.choices.map(function (n) {
            return h("button", { type: "button", "class": "choice", "data-value": String(n), onclick: function (ev) { answer(q, n, body, ev.currentTarget); } },
              n === 0 ? "Aucun" : String(n));
          }))]);
        break;
      case "nonConnecting":
        append(body, [prompt("Laquelle de ces lettres ne se lie jamais à la lettre qui suit ?"), letterChoices()]);
        break;
      case "order":
        var hint = function () { return h("span", { "class": "hint" }, "Touche les lettres dans l'ordre de l'alphabet."); };
        var seq = h("div", { "class": "sequence", "aria-label": "Ta réponse" }, hint());
        var validate = h("button", { type: "button", "class": "btn", disabled: true, onclick: function () { answer(q, state.session.sequence.slice(), body, null); } }, "Valider");
        var clear = h("button", { type: "button", "class": "btn secondary", onclick: function () {
          state.session.sequence = [];
          seq.textContent = ""; append(seq, hint());
          body.querySelectorAll(".choice").forEach(function (b) { b.disabled = false; b.classList.remove("picked"); });
          validate.disabled = true;
        } }, "Effacer");
        append(body, [prompt("Remets ces lettres dans l'ordre de l'alphabet."),
          h("p", { "class": "muted small" }, "La première lettre se place à droite."),
          seq,
          h("div", { "class": "choices letters" + (choices.length === 4 ? " four" : "") }, choices.map(function (id) {
            return h("button", { type: "button", "class": "choice", "data-value": id, "aria-label": "Lettre " + L[id].nameFr, onclick: function (ev) {
              var btn = ev.currentTarget;
              if (state.session.answered || btn.disabled) return;
              if (state.session.sequence.length === 0) seq.textContent = "";
              state.session.sequence.push(id);
              append(seq, h("span", { "class": "slot" }, ar(L[id].char)));
              btn.disabled = true; btn.classList.add("picked");
              play("tap");
              validate.disabled = state.session.sequence.length !== q.choices.length;
            } }, ar(L[id].char));
          })),
          h("div", { "class": "row" }, clear, validate)]);
        break;
      default:
        append(body, h("p", { "class": "error-box" }, "Type de question inconnu."));
    }
  }

  function answer(q, given, body, btn) {
    var s = state.session;
    if (!s || s.answered) return;   // évite un double comptage
    s.answered = true;
    var ok = Engine.isCorrect(q, given);
    if (ok) { s.correct++; s.streak++; } else { s.streak = 0; }

    body.querySelectorAll("button").forEach(function (b) { b.disabled = true; });
    if (q.type !== "order") {
      body.querySelectorAll(".choice").forEach(function (b) {
        var v = b.getAttribute("data-value");
        if (v === String(q.answer)) b.classList.add("correct");
        else if (v === String(given)) b.classList.add("wrong");
      });
    }
    if (ok && btn) btn.appendChild(h("span", { "class": "float-pts", "aria-hidden": "true" }, "+" + (s.kind === "quiz" ? Engine.QUIZ_POINTS_PER_ANSWER : state.exercises.meta.pointsPerCorrectAnswer)));
    play(ok ? "ok" : "ko");
    if (!ok) buzz(80);
    var streakEl = screen.querySelector(".streak");
    showStreak(streakEl, s.streak);
    if (ok && s.streak >= 2) { streakEl.classList.remove("hot"); void streakEl.offsetWidth; streakEl.classList.add("hot"); }
    screen.querySelector(".progress-fill").style.width = (100 * (s.index + 1) / s.questions.length) + "%";

    var last = s.index === s.questions.length - 1;
    showSheet(ok, ok ? (s.streak >= 3 ? "Excellent, " + s.streak + " d'affilée !" : "Bonne réponse !") : "Pas tout à fait",
      explanation(q, ok), last ? "Voir mon résultat" : "Continuer",
      function () { if (last) finishSession(); else { s.index++; screenQuestion(); } });
  }

  // Panneau de correction qui monte du bas (utilisé aussi par les jeux).
  function showSheet(ok, title, body, btnLabel, onNext, extra) {
    var next = h("button", { type: "button", "class": "btn block", onclick: onNext }, btnLabel);
    var text = h("div", null,
      h("p", { "class": "feedback-title" }, icon(ok ? "check" : "cross"), title),
      body ? h("p", null, body) : null);
    var sheet = h("div", { "class": "feedback " + (ok ? "ok" : "ko"), role: "status" },
      h("div", { "class": "feedback-inner" },
        isKid() ? h("div", { "class": "feedback-row" }, mascot(), text) : text,
        extra || null,
        next));
    screen.appendChild(sheet);
    next.focus({ preventScroll: true });
    return sheet;
  }

  function explanation(q, ok) {
    var L = state.byId;
    if (q.type === "order") {
      return [(ok ? "L'ordre est bien : " : "Le bon ordre est : ") + q.answer.map(function (id) { return L[id].nameFr; }).join(", ") + "."];
    }
    if (q.type === "nonConnecting") {
      var a = L[q.answer];
      return [(ok ? "" : "La bonne réponse est " + a.nameFr + " "), ar(a.char),
        ". Alif, dâl, dhâl, râ', zây et wâw ne se lient jamais à la lettre qui suit."];
    }
    if (q.type === "dots") {
      var t = L[q.letter];
      return [t.nameFr + " ", ar(t.char), " porte " + dotsText(t.dots) + "."];
    }
    var l = L[q.answer];
    return [(ok ? "C'est bien " : "La bonne réponse est ") + l.nameFr + " ", ar(l.char), " : " + l.sound + "."];
  }

  function finishSession() {
    var s = state.session;
    var total = s.questions.length;
    var before = points();
    var passRatio = s.kind === "quiz" ? QUIZ_PASS : ratio();
    if (s.kind === "quiz") Engine.recordQuiz(state.progress, s.correct, total);
    else Engine.recordExercise(state.progress, s.exercise.id, s.correct, total);
    saveProgress();
    var nextEx = null;
    if (s.kind === "exercise") nextEx = state.exercises.exercises.filter(function (e) { return e.number === s.exercise.number + 1; })[0] || null;
    state.lastResult = {
      kind: s.kind, correct: s.correct, total: total, gained: points() - before,
      passed: s.correct / total >= passRatio, need: Math.ceil(total * passRatio),
      stars: Engine.stars({ best: s.correct, total: total }, passRatio),
      nextEx: nextEx, again: s.kind === "quiz" ? "#/quiz" : "#/jouer/" + s.exercise.id, fresh: true,
      back: "#/parcours", backLabel: "Retour au parcours"
    };
    state.session = null;
    // L'adresse devient #/resultat : « Recommencer » mène ainsi vers une autre adresse.
    history.replaceState(null, "", "#/resultat");
    screenResult();
  }

  function screenResult() {
    var r = state.lastResult;
    if (!r) return screenHome();
    var starsTop = isKid() ? mascot("bounce") : null;
    var stars = h("div", { "class": "result-stars", "aria-label": r.stars + " étoile" + (r.stars > 1 ? "s" : "") + " sur 3" });
    for (var i = 0; i < 3; i++) { var st = icon("star"); if (i < r.stars) st.classList.add("on"); stars.appendChild(st); }
    render([
      h("div", { "class": "result" },
        starsTop,
        stars,
        h("h1", null, r.passed ? (r.stars === 3 ? "Sans faute, mâ châ' Allah !" : "Bravo, mâ châ' Allah !") : "Continue, tu progresses !"),
        h("p", { "class": "score-big" }, r.correct + " / " + r.total),
        r.gained > 0
          ? h("p", { "class": "result-gain" }, icon("star"), "+" + r.gained + " points")
          : h("p", { "class": "muted small" }, "Pas de nouveaux points : seul ton meilleur score compte."),
        h("p", { "class": "muted" }, r.passed
          ? (r.kind === "quiz" ? "Quiz réussi." : r.kind === "game" ? "Bien joué ! Essaie un autre jeu ou rejoue pour gagner plus d'étoiles." : "Étape réussie. La suite t'attend sur le parcours.")
          : "Il faut " + r.need + " bonnes réponses pour réussir. Revois les lettres, puis réessaie sans te presser.")),
      h("div", { "class": "stack" },
        r.nextEx && r.passed ? h("a", { "class": "btn block", href: "#/jouer/" + r.nextEx.id }, "Exercice suivant : " + r.nextEx.title) : null,
        h("a", { "class": r.passed && r.nextEx ? "btn secondary block" : "btn block", href: r.again }, "Recommencer"),
        h("a", { "class": "btn secondary block", href: r.back }, r.backLabel))
    ], "Résultat");
    if (r.fresh) {
      r.fresh = false;
      if (r.passed) { play("win"); confetti(); }
    }
  }

  // Fin d'un mini-jeu : enregistre le score et affiche le résultat.
  function finishGame(gameId, title, correct, total, passRatio) {
    var before = points();
    Engine.recordGame(state.progress, gameId, correct, total);
    saveProgress();
    state.lastResult = {
      kind: "game", correct: correct, total: total, gained: points() - before,
      passed: correct / total >= passRatio, need: Math.ceil(total * passRatio),
      stars: Engine.stars({ best: correct, total: total }, passRatio),
      nextEx: null, again: "#/jeu/" + gameId, fresh: true, back: "#/jeux", backLabel: "Retour aux jeux", title: title
    };
    history.replaceState(null, "", "#/resultat");
    screenResult();
  }

  /* ---------- Écran : progrès ---------- */
  function screenProgress() {
    var ex = state.exercises;
    var passed = Engine.countPassed(state.progress, ratio());
    var pct = Math.round(100 * passed / ex.exercises.length);
    var C = 2 * Math.PI * 48;
    var NS = "http://www.w3.org/2000/svg";
    var ring = document.createElementNS(NS, "svg");
    ring.setAttribute("viewBox", "0 0 112 112"); ring.setAttribute("aria-hidden", "true");
    [["track", 0], ["value", C * (1 - pct / 100)]].forEach(function (c) {
      var el = document.createElementNS(NS, "circle");
      el.setAttribute("cx", "56"); el.setAttribute("cy", "56"); el.setAttribute("r", "48");
      el.setAttribute("class", c[0]);
      if (c[0] === "value") { el.setAttribute("stroke-dasharray", String(C)); el.setAttribute("stroke-dashoffset", String(c[1])); }
      ring.appendChild(el);
    });
    var badgeIcons = { first: "flag", level: "mountain", perfect: "target", five: "flame", quiz: "bolt", explorer: "puzzle", all: "crown" };
    var gameNames = { images: "Quelle image ?", memory: "Mémoire", trace: "Tracer", spell: "Épeler" };
    render([
      h("h1", null, "Mes progrès"),
      h("div", { "class": "panel overview" },
        h("div", { "class": "ring" }, ring, h("div", { "class": "ring-label" }, h("div", null, h("b", null, pct + "%"), h("br"), h("span", null, "du parcours")))),
        h("div", { "class": "overview-text" },
          h("b", null, passed === ex.exercises.length ? "Parcours terminé !" : "Continue, tu avances bien."),
          h("span", { "class": "muted small" }, "Meilleur quiz : " + (state.progress.quiz.total ? state.progress.quiz.best + "/" + state.progress.quiz.total : "pas encore fait")))),
      h("div", { "class": "stats" },
        stat(points(), "points"),
        stat(passed + "/" + ex.exercises.length, "exercices réussis"),
        stat(totalStars() + "/" + ex.exercises.length * 3, "étoiles")),
      h("div", { "class": "section" },
        h("h2", null, "Par étape"),
        h("div", { "class": "panel levels" }, ex.levels.map(function (lv) {
          var list = ex.exercises.filter(function (e) { return e.level === lv.level; });
          var done = list.filter(function (e) { return Engine.isPassed(state.progress.exercises[e.id], ratio()); }).length;
          var fill = h("div");
          fill.style.width = (100 * done / list.length) + "%";
          return h("div", { "class": "level-row" },
            h("div", { "class": "label" }, h("span", null, lv.title), h("span", null, done + "/" + list.length)),
            h("div", { "class": "bar" }, fill));
        }))),
      h("div", { "class": "section" },
        h("h2", null, "Jeux"),
        h("div", { "class": "panel levels" }, Engine.GAME_IDS.map(function (g) {
          var e = state.progress.games && state.progress.games[g];
          return h("div", { "class": "level-row" },
            h("div", { "class": "label" }, h("span", null, gameNames[g]),
              h("span", null, e ? "meilleur score " + e.best + "/" + e.total : "pas encore joué")));
        }))),
      h("div", { "class": "section" },
        h("h2", null, "Badges"),
        h("div", { "class": "badges" }, Engine.badges(state.progress, ex).map(function (b) {
          return h("div", { "class": "badge" + (b.earned ? " earned" : "") },
            h("span", { "class": "badge-ico" }, icon(badgeIcons[b.id] || "star")),
            h("span", null, h("b", null, b.title), h("span", null, b.desc)));
        }))),
      h("p", { "class": "muted small" }, "Ta progression est enregistrée uniquement sur cet appareil. Aucune donnée n'est envoyée sur Internet.")
    ], "Progrès");
  }

  /* ---------- Écran : paramètres ---------- */
  function screenSettings() {
    function toggle(id, key, title, desc) {
      var input = h("input", { type: "checkbox", id: id, role: "switch", onchange: function (ev) {
        state.settings[key] = ev.currentTarget.checked; saveSettings();
        if (key === "sound" && state.settings.sound) play("ok");
        if (key === "vibrate" && state.settings.vibrate) buzz(40);
      } });
      input.checked = state.settings[key];
      return h("div", { "class": "setting" },
        h("label", { "class": "setting-text", "for": id }, h("b", null, title), h("span", null, desc)),
        h("span", { "class": "switch" }, input, h("span", { "class": "track" })));
    }
    function segmented(label, options, current, onPick) {
      var group = h("div", { "class": "segmented", role: "group", "aria-label": label });
      options.forEach(function (o) {
        group.appendChild(h("button", { type: "button", "aria-pressed": String(o[0] === current), onclick: function () {
          onPick(o[0]);
          group.querySelectorAll("button").forEach(function (b) { b.setAttribute("aria-pressed", String(b === this)); }, this);
        } }, o[1]));
      });
      return group;
    }
    var resetBtn = h("button", { type: "button", "class": "btn danger block", onclick: askReset }, "Effacer ma progression");
    render([
      backLink("#/accueil", "Accueil"),
      h("h1", null, "Paramètres"),
      h("div", { "class": "settings" },
        h("div", { "class": "setting" },
          h("div", { "class": "setting-text" }, h("b", null, "Profil"), h("span", null, "Enfant : couleurs vives et Jamal. Adulte : style sobre.")),
          segmented("Profil", [["kid", "Enfant"], ["adult", "Adulte"]], state.settings.mode,
            function (v) { state.settings.mode = v; saveSettings(); })),
        toggle("set-sound", "sound", "Sons", "Petits sons pour les bonnes et mauvaises réponses"),
        toggle("set-vibrate", "vibrate", "Vibration", "Le téléphone vibre en cas d'erreur"),
        h("div", { "class": "setting" },
          h("div", { "class": "setting-text" }, h("b", null, "Apparence"), h("span", null, "Auto suit le réglage du téléphone")),
          segmented("Apparence", [["auto", "Auto"], ["light", "Clair"], ["dark", "Sombre"]], state.settings.theme,
            function (v) { state.settings.theme = v; saveSettings(); })),
        h("div", { "class": "setting" },
          h("div", { "class": "setting-text" }, h("b", null, "Taille du texte"), h("span", null, "Pour lire plus confortablement")),
          segmented("Taille du texte", [[false, "Normale"], [true, "Grande"]], state.settings.textLarge,
            function (v) { state.settings.textLarge = v; saveSettings(); }))),
      h("div", { "class": "section" },
        h("h2", null, "Voix"),
        h("p", { "class": "muted small" }, hasArabicVoice()
          ? "Une voix arabe est installée sur ce téléphone. Elle est provisoire : des enregistrements d'un enseignant la remplaceront."
          : "Pas de voix arabe détectée. Sur Android : Paramètres › Gestion générale ou Accessibilité › Synthèse vocale › Moteur Google › installer « Arabe »."),
        h("div", { "class": "listen-row" }, speakBtn("بِسْمِ اللّٰهِ", "test", "test", "Tester la voix"), h("span", { "class": "muted" }, "Tester la voix")),
        NATIVE ? h("p", { "class": "muted small", id: "tts-status" }, (function () { try { return window.AndroidTTS.status(); } catch (e) { return ""; } })()) : null,
        NATIVE ? h("button", { type: "button", "class": "btn secondary block", id: "open-tts", onclick: function () {
          try { window.AndroidTTS.openTtsSettings(); } catch (e) { toast("Réglage introuvable sur ce téléphone."); }
        } }, "Installer la voix arabe") : null),
      h("div", { "class": "section" },
        h("h2", null, "Ma progression"),
        h("p", { "class": "muted small" }, "Tes points et tes étoiles sont enregistrés seulement sur ce téléphone, dans ce navigateur."),
        resetBtn),
      h("a", { "class": "btn secondary block", href: "#/a-propos" }, "À propos du projet")
    ], "Paramètres");
  }
  // Confirmation affichée dans la page (pas de fenêtre « confirm », bloquée dans certains navigateurs).
  function askReset(ev) {
    var btn = ev.currentTarget;
    var box = h("div", { "class": "confirm-box", role: "alertdialog", "aria-label": "Confirmer l'effacement" },
      h("p", null, "Effacer tous tes points, étoiles et exercices réussis ? Cette action est définitive."),
      h("div", { "class": "row" },
        h("button", { type: "button", "class": "btn secondary", onclick: function () { box.replaceWith(btn); btn.focus(); } }, "Annuler"),
        h("button", { type: "button", "class": "btn danger", id: "confirm-reset", onclick: function () {
          state.progress = Engine.newProgress(); saveProgress(); screenSettings();
        } }, "Oui, tout effacer")));
    btn.replaceWith(box);
    box.querySelector("#confirm-reset").focus();
  }

  /* ---------- Premier lancement : choix du profil ---------- */
  function screenWelcome() {
    function pick(mode) {
      return function () {
        state.settings.mode = mode; saveSettings(); play("tap");
        window.location.hash = "#/accueil";
        if (window.location.hash === "#/accueil") route();
      };
    }
    render([
      h("div", { "class": "welcome" },
        h("div", { "class": "welcome-head" },
          h("p", { "class": "eyebrow" }, "Bienvenue"),
          h("h1", null, "Le Voyage du Coran"),
          ar("رِحْلَةُ الْقُرْآنِ"),
          h("p", { "class": "muted" }, "Qui va jouer sur ce téléphone ?")),
        h("button", { type: "button", "class": "mode-card mode-kid", id: "mode-kid", onclick: pick("kid") },
          mascot("bounce"),
          h("span", null, h("b", null, "Enfant"), h("span", null, "Des couleurs, des images, des jeux et Jamal le chameau."))),
        h("button", { type: "button", "class": "mode-card mode-adult", id: "mode-adult", onclick: pick("adult") },
          h("span", { "class": "mode-ico" }, icon("crescent")),
          h("span", null, h("b", null, "Adolescent ou adulte"), h("span", null, "Le même contenu, dans un style plus sobre."))),
        h("p", { "class": "muted small", style: null }, "Tu pourras changer à tout moment dans Paramètres."))
    ], "Bienvenue", { playing: true });
  }

  /* ---------- Écran : à propos ---------- */
  function screenAbout() {
    function block(title, paras) {
      return h("div", { "class": "panel prose" }, h("h2", null, title), paras.map(function (p) { return h("p", null, p); }));
    }
    render([
      backLink("#/accueil", "Accueil"),
      h("h1", null, "Notre mission"),
      block("Le projet", ["Le Voyage du Coran est un projet éducatif gratuit, né au Niger, qui aide les familles à apprendre l'alphabet arabe, puis, progressivement, la lecture du Coran, les hadiths et l'éducation islamique.",
        "Ce jeu ne remplace pas un enseignant qualifié : il l'accompagne."]),
      block("Version 0.2 — prototype", ["Cette version contient seulement l'alphabet arabe : 28 lettres, 15 exercices et un quiz.",
        "Elle ne contient aucun verset du Coran ni aucun hadith. Ils seront ajoutés plus tard, à partir de sources fiables, et seulement après vérification par des relecteurs qualifiés."]),
      block("Sources et vérification", ["Les noms, formes et descriptions des lettres ont été préparés avec l'aide d'une intelligence artificielle. Ils restent en statut « " + (state.letters.meta.status || "inconnu") + " » tant qu'un enseignant d'arabe ne les a pas vérifiés.",
        "Polices : Lexend, Baloo Bhaijaan 2 et Noto Naskh Arabic, sous licence SIL Open Font License 1.1."]),
      block("Vie privée", ["Aucun compte, aucune publicité, aucune collecte de données. La progression reste sur ton appareil."])
    ], "À propos");
  }

  function screenNotFound() {
    render([h("h1", null, "Page introuvable"), h("p", { "class": "muted" }, "Cette adresse n'existe pas dans le jeu."),
      h("a", { "class": "btn", href: "#/accueil" }, "Retour à l'accueil")], "Introuvable");
  }

  /* ---------- Navigation ---------- */
  function route() {
    var parts = window.location.hash.replace(/^#\/?/, "").split("/");
    var name = parts[0] || "accueil";
    if (name === "exercices") name = "parcours";   // ancienne adresse
    if (!state.settings.mode && name !== "a-propos") name = "bienvenue";
    var tab = { accueil: "accueil", parcours: "parcours", jouer: "parcours", resultat: state.lastResult && state.lastResult.kind === "game" ? "jeux" : "parcours",
      jeux: "jeux", jeu: "jeux", alphabet: "alphabet", lettre: "alphabet", progres: "progres" }[name];
    document.querySelectorAll(".tabbar a").forEach(function (a) {
      if (a.getAttribute("data-tab") === tab) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });
    switch (name) {
      case "accueil": return screenHome();
      case "parcours": return screenJourney();
      case "alphabet": return screenAlphabet();
      case "lettre": return screenLetter(parts[1]);
      case "jouer": return startExercise(parts[1]);
      case "quiz": return startQuiz();
      case "resultat": return screenResult();
      case "progres": return screenProgress();
      case "parametres": return screenSettings();
      case "a-propos": return screenAbout();
      case "bienvenue": return screenWelcome();
      case "jeux": return window.VDCGames ? window.VDCGames.menu() : screenNotFound();
      case "jeu": return window.VDCGames ? window.VDCGames.play(parts[1]) : screenNotFound();
      default: return screenNotFound();
    }
  }

  // Flèches du clavier sur la fiche d'une lettre (ordre arabe : gauche = suivante).
  document.addEventListener("keydown", function (ev) {
    if (ev.key !== "ArrowLeft" && ev.key !== "ArrowRight") return;
    if (!/^#\/lettre\//.test(window.location.hash)) return;
    var link = screen.querySelector('[data-nav="' + (ev.key === "ArrowLeft" ? "next" : "prev") + '"]');
    if (link) window.location.hash = link.getAttribute("href");
  });

  /* ---------- Démarrage ---------- */
  function fetchJson(url) {
    if (window.VDC_CONTENT && window.VDC_CONTENT[url]) return Promise.resolve(window.VDC_CONTENT[url]);
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error(url + " (erreur " + r.status + ")");
      return r.json();
    });
  }

  function start() {
    loadSettings();
    Promise.all([fetchJson("content/arabic-letters.json"), fetchJson("content/exercises.json"),
      fetchJson("content/words.json"), fetchJson("content/audio.json").catch(function () { return { letters: {}, words: {} }; })])
      .then(function (data) {
        state.letters = data[0];
        state.exercises = data[1];
        state.words = data[2];
        state.audio = { letters: (data[3] && data[3].letters) || {}, words: (data[3] && data[3].words) || {} };
        var errors = Engine.validateContent(state.letters, state.exercises).concat(Engine.validateWords(state.letters, state.words));
        if (errors.length) throw new Error("Contenu invalide : " + errors.join(" ; "));
        state.letters.letters.forEach(function (l) { state.byId[l.id] = l; });
        state.words.words.forEach(function (w) { state.wordByLetter[w.letter] = w; state.wordById[w.id] = w; });
        loadProgress();
        updatePoints();
        window.addEventListener("hashchange", route);
        route();
      })
      .catch(function (err) {
        render([
          h("div", { "class": "error-box" },
            h("h1", null, "Impossible de charger le jeu"),
            h("p", null, "Vérifie ta connexion Internet lors de la première ouverture, puis réessaie."),
            h("p", { "class": "small" }, String(err && err.message ? err.message : err))),
          h("button", { type: "button", "class": "btn", onclick: function () { window.location.reload(); } }, "Réessayer")
        ], "Erreur");
      });
  }

  // Le service worker permet de rouvrir le jeu sans Internet (https ou localhost seulement).
  // Pas de service worker dans l'application Android : les fichiers y sont déjà sur le téléphone.
  if (!NATIVE && "serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1")) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("service-worker.js").catch(function () { /* le jeu marche quand même en ligne */ });
    });
  }

  // Outils partagés avec js/games.js
  window.VDC = {
    state: state, h: h, ar: ar, icon: icon, render: render, backLink: backLink, plural: plural,
    play: play, buzz: buzz, speak: speak, speakBtn: speakBtn, mascot: mascot, isKid: isKid, toast: toast,
    showSheet: showSheet, finishGame: finishGame, starsRow: starsRow, confetti: confetti
  };

  // Démarre quand toutes les pages de script sont chargées (games.js compris).
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
