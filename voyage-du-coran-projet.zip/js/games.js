/*
 * Le Voyage du Coran — les quatre mini-jeux (v0.3).
 *
 *   images : « Quelle image ? »   mot ↔ image, lettre → image
 *   memory : jeu de mémoire        retrouver les paires lettre ↔ image
 *   trace  : tracer la lettre      suivre la lettre avec le doigt
 *   spell  : épeler un mot         remettre les lettres dans l'ordre
 *
 * Les outils d'affichage viennent de js/app.js (window.VDC).
 * La logique testable (paquet de cartes, score du tracé) est dans js/engine.js.
 */
(function () {
  "use strict";
  var V = window.VDC;
  var h = V.h, ar = V.ar, icon = V.icon;
  var S = V.state;

  var GAMES = [
    { id: "images", title: "Quelle image ?", desc: "Associer le mot, la lettre et l'image", art: ["🦁", "🍎", "🐪"], rounds: 8, pass: 0.75 },
    { id: "memory", title: "Mémoire", desc: "Retrouver les paires lettre et image", art: ["ب", "🦆"], rounds: 6, pass: 0.66 },
    { id: "trace", title: "Tracer", desc: "Suivre la lettre avec le doigt", art: ["✍️", "ج"], rounds: 5, pass: 0.6 },
    { id: "spell", title: "Épeler", desc: "Remettre les lettres du mot dans l'ordre", art: ["🐘", "فيل"], rounds: 6, pass: 0.66 }
  ];
  function game(id) { return GAMES.filter(function (g) { return g.id === id; })[0]; }
  function words() { return S.words.words; }
  function pick(list, n, exclude) {
    return Engine.shuffled(list.filter(function (x) { return (exclude || []).indexOf(x) < 0; })).slice(0, n);
  }
  function artNode(a) { return /[؀-ۿ]/.test(a) ? ar(a) : h("span", null, a); }

  /* ---------- Menu des jeux ---------- */
  function menu() {
    V.render([
      V.isKid() ? h("div", { "class": "say" }, V.mascot("bounce"), h("p", { "class": "bubble-say" }, "Choisis un jeu ! Chaque jeu te fait gagner des points et des étoiles.")) : null,
      h("h1", null, "Les jeux"),
      h("p", { "class": "muted" }, "Quatre façons de jouer avec les 28 lettres et leurs mots."),
      h("div", { "class": "games" }, GAMES.map(function (g) {
        var e = S.progress.games && S.progress.games[g.id];
        return h("a", { "class": "game-card game-" + g.id, href: "#/jeu/" + g.id },
          h("span", { "class": "art", "aria-hidden": "true" }, g.art.map(artNode)),
          h("b", null, g.title),
          h("span", null, g.desc),
          V.starsRow(Engine.stars(e, g.pass)));
      })),
      h("p", { "class": "notice" }, icon("info"), h("span", null, "Les images sont les emoji de ton téléphone. Les mots sont en brouillon : un enseignant doit encore les vérifier."))
    ], "Jeux");
  }

  /* ---------- Cadre commun d'une partie ---------- */
  function shell(g, round, total, body) {
    var fill = h("div", { "class": "progress-fill" });
    V.render([
      h("div", { "class": "play-top" },
        h("a", { "class": "icon-btn", href: "#/jeux", "aria-label": "Quitter" }, icon("close")),
        h("div", { "class": "progress-track", role: "progressbar", "aria-label": "Manche " + (round + 1) + " sur " + total,
          "aria-valuemin": "0", "aria-valuemax": String(total), "aria-valuenow": String(round) }, fill),
        h("span", { "class": "streak" })),
      h("div", { "class": "q-head" }, h("p", { "class": "eyebrow" }, g.title), h("p", { "class": "muted small" }, "Manche " + (round + 1) + " sur " + total)),
      body,
      h("div", { "class": "sheet-space", "aria-hidden": "true" })
    ], g.title, { playing: true });
    fill.style.width = (100 * round / total) + "%";
    return fill;
  }

  /* ========== 1. Quelle image ? ========== */
  function playImages() {
    var g = game("images");
    var list = pick(words(), g.rounds);
    var types = ["wordToPic", "picToWord", "letterToPic"];
    var st = { i: 0, correct: 0 };
    function round() {
      var w = list[st.i];
      var type = types[st.i % types.length];
      var others = pick(words(), 3, [w]);
      var body = h("div", { "class": "section", "data-answer": w.id });
      shell(g, st.i, list.length, body);
      function done(ok, btn) {
        body.querySelectorAll("button.pic, button.choice").forEach(function (b) {
          b.disabled = true;
          if (b.getAttribute("data-value") === w.id) b.classList.add("correct");
          else if (b === btn) b.classList.add("wrong");
        });
        if (ok) st.correct++;
        V.play(ok ? "ok" : "ko"); if (!ok) V.buzz(80);
        if (ok) V.speak(w.word, "words", w.id, null, true);
        var last = st.i === list.length - 1;
        V.showSheet(ok, ok ? "Bravo !" : "Pas tout à fait",
          [w.emoji + " ", ar(w.word), " : " + w.translit + ", « " + w.fr + " »."],
          last ? "Voir mon résultat" : "Continuer",
          function () { if (last) V.finishGame("images", g.title, st.correct, list.length, g.pass); else { st.i++; round(); } });
      }
      var options = Engine.shuffled([w].concat(others));
      if (type === "wordToPic" || type === "letterToPic") {
        var l = S.byId[w.letter];
        body.appendChild(h("h1", { "class": "q-prompt" }, type === "wordToPic" ? "Touche l'image de ce mot" : "Quelle image commence par cette lettre ?"));
        body.appendChild(type === "wordToPic"
          ? h("div", { "class": "target" }, ar(w.word), V.speakBtn(w.word, "words", w.id, "Écouter le mot"))
          : h("div", { "class": "target" }, ar(l.char), V.speakBtn(l.nameAr, "letters", l.id, "Écouter la lettre")));
        body.appendChild(h("div", { "class": "pic-choices" }, options.map(function (o) {
          return h("button", { type: "button", "class": "pic", "data-value": o.id, "aria-label": o.fr, onclick: function (ev) { done(o === w, ev.currentTarget); } }, o.emoji);
        })));
      } else {
        var three = Engine.shuffled([w].concat(others.slice(0, 2)));
        body.appendChild(h("h1", { "class": "q-prompt" }, "Quel est le mot de cette image ?"));
        body.appendChild(h("div", { "class": "target" }, h("span", { "class": "big-emoji", "aria-label": w.fr }, w.emoji)));
        body.appendChild(h("div", { "class": "choices" }, three.map(function (o) {
          return h("button", { type: "button", "class": "choice word-choice", "data-value": o.id, onclick: function (ev) { done(o === w, ev.currentTarget); } },
            ar(o.word), V.isKid() ? null : h("small", null, o.translit));
        })));
      }
    }
    round();
  }

  /* ========== 2. Mémoire ========== */
  function playMemory() {
    var g = game("memory");
    var deck = Engine.buildMemoryDeck(S.words, g.rounds);
    var open = [], found = 0, moves = 0, lock = false;
    var info = h("div", { "class": "memory-info" }, h("span", { id: "mem-pairs" }, "Paires : 0/" + g.rounds), h("span", { id: "mem-moves" }, "Coups : 0"));
    var grid = h("div", { "class": "memory" });
    var body = h("div", { "class": "section" },
      h("h1", { "class": "q-prompt" }, "Retrouve chaque lettre et l'image de son mot"), info, grid);
    var fill = shell(g, 0, g.rounds, body);
    var star = '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="5" width="14" height="14"/><rect x="5" y="5" width="14" height="14" transform="rotate(45 12 12)"/><circle cx="12" cy="12" r="3"/></g></svg>';
    deck.forEach(function (c, idx) {
      var front;
      if (c.kind === "letter") { var l = S.byId[c.letter]; front = h("span", { "class": "face mem-front" }, ar(l.char), h("small", null, l.nameFr)); }
      else { var w = S.wordById[c.word]; front = h("span", { "class": "face mem-front" }, h("span", { "class": "em" }, w.emoji), ar(w.word, "mem-word")); }
      var back = h("span", { "class": "face mem-back" });
      back.innerHTML = star;   // constante, aucun contenu externe
      var btn = h("button", { type: "button", "class": "card", "data-pair": c.pair, "data-kind": c.kind, "aria-label": "Carte " + (idx + 1) + ", cachée" }, back, front);
      btn.addEventListener("click", function () { flip(btn, c); });
      grid.appendChild(btn);
    });
    function flip(btn, c) {
      if (lock || btn.classList.contains("open") || btn.classList.contains("found")) return;
      btn.classList.add("open");
      btn.setAttribute("aria-label", c.kind === "letter" ? "Lettre " + S.byId[c.letter].nameFr : "Image : " + S.wordById[c.word].fr);
      V.play("tap");
      open.push({ btn: btn, c: c });
      if (open.length < 2) return;
      moves++;
      document.getElementById("mem-moves").textContent = "Coups : " + moves;
      var a = open[0], b = open[1];
      open = [];
      if (a.c.pair === b.c.pair && a.c.kind !== b.c.kind) {
        found++;
        [a, b].forEach(function (x) { x.btn.classList.remove("open"); x.btn.classList.add("found"); });
        document.getElementById("mem-pairs").textContent = "Paires : " + found + "/" + g.rounds;
        fill.style.width = (100 * found / g.rounds) + "%";
        V.play("ok");
        var w = S.wordById[a.c.pair];
        V.speak(w.word, "words", w.id, null, true);
        if (found === g.rounds) {
          // 3 étoiles jusqu'à 9 coups, 2 jusqu'à 14, sinon 1.
          var score = moves <= 9 ? 6 : moves <= 14 ? 4 : 2;
          setTimeout(function () {
            V.showSheet(true, "Toutes les paires !", "Tu as réussi en " + moves + " coups.", "Voir mon résultat",
              function () { V.finishGame("memory", g.title, score, g.rounds, g.pass); });
          }, 500);
        }
      } else {
        lock = true;
        [a, b].forEach(function (x) { x.btn.classList.add("miss"); });
        setTimeout(function () {
          [a, b].forEach(function (x) { x.btn.classList.remove("open", "miss"); x.btn.setAttribute("aria-label", "Carte cachée"); });
          lock = false;
        }, 900);
      }
    }
  }

  /* ========== 3. Tracer ========== */
  var GRID = 48;   // la lettre est comparée sur une grille de 48 × 48 cases
  function playTrace() {
    var g = game("trace");
    var letters = Engine.shuffled(S.letters.letters).slice(0, g.rounds);
    var st = { i: 0, correct: 0, tries: 0, color: "#2f7cf6" };
    var fontReady = document.fonts && document.fonts.load ? document.fonts.load('400 200px "Noto Naskh Arabic"', "بجس").catch(function () {}) : Promise.resolve();
    function round() {
      var l = letters[st.i];
      st.tries = 0;
      var wrap = h("div", { "class": "trace-wrap" });
      var guide = h("canvas", { "class": "guide", "aria-hidden": "true" });
      var ink = h("canvas", { "class": "ink", "aria-label": "Zone de tracé de la lettre " + l.nameFr, role: "img" });
      wrap.appendChild(guide); wrap.appendChild(ink);
      var colors = ["#2f7cf6", "#e5484d", "#10996f", "#9b4dea", "#f08a00"];
      var palette = h("div", { "class": "palette", role: "group", "aria-label": "Couleur" }, colors.map(function (c) {
        var b = h("button", { type: "button", "aria-label": "Couleur", "aria-pressed": String(c === st.color), onclick: function () {
          st.color = c; palette.querySelectorAll("button").forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
        } });
        b.style.setProperty("--c", c);
        return b;
      }));
      var check = h("button", { type: "button", "class": "btn", id: "trace-check" }, "Vérifier");
      var clear = h("button", { type: "button", "class": "btn secondary", id: "trace-clear" }, "Effacer");
      var body = h("div", { "class": "section", "data-letter": l.id },
        h("div", { "class": "trace-head" },
          h("h1", { "class": "q-prompt" }, "Trace la lettre ", l.nameFr),
          V.speakBtn(l.nameAr, "letters", l.id, "Écouter la lettre", true)),
        wrap, palette, h("div", { "class": "row" }, clear, check),
        h("p", { "class": "muted small" }, "Suis la lettre en pointillés avec ton doigt. Le jeu vérifie la forme, pas encore le sens du tracé."));
      shell(g, st.i, letters.length, body);

      var size = Math.round(wrap.getBoundingClientRect().width) || 300;
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      [guide, ink].forEach(function (c) { c.width = size * dpr; c.height = size * dpr; });
      var gctx = guide.getContext("2d"), ictx = ink.getContext("2d");
      gctx.scale(dpr, dpr); ictx.scale(dpr, dpr);
      var mask = new Uint8Array(GRID * GRID), zone = null;
      var cssVar = function (n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); };

      fontReady.then(function () {
        // Lettre placée au centre, mesurée pour être bien cadrée.
        var fontPx = size * 0.62;
        var font = '400 ' + fontPx + 'px "Noto Naskh Arabic", serif';
        gctx.font = font; gctx.textAlign = "center"; gctx.textBaseline = "alphabetic"; gctx.direction = "rtl";
        var m = gctx.measureText(l.char);
        var gh = (m.actualBoundingBoxAscent || fontPx * .6) + (m.actualBoundingBoxDescent || fontPx * .2);
        var y = size / 2 + gh / 2 - (m.actualBoundingBoxDescent || fontPx * .2);
        var x = size / 2;
        gctx.fillStyle = cssVar("--primary-soft") || "#dcefe7";
        gctx.fillText(l.char, x, y);
        gctx.setLineDash([1, 10]); gctx.lineCap = "round"; gctx.lineWidth = 5;
        gctx.strokeStyle = cssVar("--primary") || "#0e6650";
        gctx.strokeText(l.char, x, y);
        // Masque de la lettre, réduit à la grille.
        var off = document.createElement("canvas"); off.width = GRID; off.height = GRID;
        var octx = off.getContext("2d");
        var k = GRID / size;
        octx.font = '400 ' + (fontPx * k) + 'px "Noto Naskh Arabic", serif';
        octx.textAlign = "center"; octx.textBaseline = "alphabetic"; octx.direction = "rtl";
        octx.fillStyle = "#000"; octx.fillText(l.char, x * k, y * k);
        var px = octx.getImageData(0, 0, GRID, GRID).data;
        for (var i = 0; i < GRID * GRID; i++) mask[i] = px[i * 4 + 3] > 90 ? 1 : 0;
        zone = Engine.dilate(mask, GRID, 3);   // tolérance : environ l'épaisseur d'un doigt
        wrap.setAttribute("data-ready", "1");
      });

      // Dessin au doigt (ou à la souris).
      var drawing = false, last = null;
      ictx.lineCap = "round"; ictx.lineJoin = "round";
      function pos(ev) { var r = ink.getBoundingClientRect(); return { x: (ev.clientX - r.left) * size / r.width, y: (ev.clientY - r.top) * size / r.height }; }
      ink.addEventListener("pointerdown", function (ev) {
        drawing = true; last = pos(ev); ink.setPointerCapture && ink.setPointerCapture(ev.pointerId);
        ictx.strokeStyle = st.color; ictx.lineWidth = size * 0.075;
        ictx.beginPath(); ictx.moveTo(last.x, last.y); ictx.lineTo(last.x + .1, last.y + .1); ictx.stroke();
      });
      ink.addEventListener("pointermove", function (ev) {
        if (!drawing) return;
        var p = pos(ev);
        ictx.beginPath(); ictx.moveTo(last.x, last.y); ictx.lineTo(p.x, p.y); ictx.stroke();
        last = p;
      });
      ["pointerup", "pointercancel", "pointerleave"].forEach(function (t) { ink.addEventListener(t, function () { drawing = false; }); });

      clear.addEventListener("click", function () { ictx.clearRect(0, 0, size, size); });
      check.addEventListener("click", function () {
        var off = document.createElement("canvas"); off.width = GRID; off.height = GRID;
        var octx = off.getContext("2d");
        octx.drawImage(ink, 0, 0, GRID, GRID);
        var px = octx.getImageData(0, 0, GRID, GRID).data;
        var drawn = new Uint8Array(GRID * GRID);
        for (var i = 0; i < GRID * GRID; i++) drawn[i] = px[i * 4 + 3] > 40 ? 1 : 0;
        var score = Engine.traceScore(mask, drawn, zone);
        if (score.drawn === 0) { V.toast("Trace la lettre avec ton doigt, puis touche « Vérifier »."); return; }
        var ok = Engine.tracePassed(score);
        body.setAttribute("data-score", score.coverage.toFixed(2) + "," + score.spill.toFixed(2));
        st.tries++;
        V.play(ok ? "ok" : "ko"); if (!ok) V.buzz(80);
        var last = st.i === letters.length - 1;
        function next() { if (last) V.finishGame("trace", g.title, st.correct, letters.length, g.pass); else { st.i++; round(); } }
        if (ok) {
          st.correct++;
          V.showSheet(true, "Très beau tracé !", ["Tu as tracé ", ar(l.char), " (" + l.nameFr + ")."], last ? "Voir mon résultat" : "Lettre suivante", next);
        } else if (st.tries < 2) {
          var sheet = V.showSheet(false, "Encore un essai", score.coverage < 0.55 ? "Essaie de recouvrir toute la lettre en pointillés." : "Reste bien sur la lettre, sans déborder.", "Réessayer", function () {
            sheet.remove(); ictx.clearRect(0, 0, size, size);
          });
        } else {
          V.showSheet(false, "On passe à la suivante", "Tu pourras retracer cette lettre une autre fois.", last ? "Voir mon résultat" : "Lettre suivante", next);
        }
      });
    }
    round();
  }

  /* ========== 4. Épeler ========== */
  function playSpell() {
    var g = game("spell");
    var list = pick(words().filter(function (w) { return w.spell; }), g.rounds);
    var st = { i: 0, correct: 0 };
    function round() {
      var w = list[st.i];
      var extra = pick(S.letters.letters.map(function (l) { return l.id; }), 2, w.spell);
      var tilesIds = Engine.shuffled(w.spell.concat(extra));
      var given = [];
      var slots = h("div", { "class": "slots", "aria-label": "Ta réponse" });
      w.spell.forEach(function () { slots.appendChild(h("span", { "class": "slot-box" })); });
      var tiles = h("div", { "class": "spell-tiles" });
      var body = h("div", { "class": "section", "data-answer": w.spell.join(",") },
        h("h1", { "class": "q-prompt" }, "Écris le mot de cette image"),
        h("div", { "class": "target" }, h("span", { "class": "big-emoji", "aria-label": w.fr }, w.emoji),
          h("div", null, h("b", null, w.fr), h("p", { "class": "muted small" }, plural(w.spell.length, "lettre", "lettres"))),
          V.speakBtn(w.word, "words", w.id, "Écouter le mot")),
        h("p", { "class": "muted small" }, "Touche les lettres dans l'ordre. La première se place à droite."),
        slots, tiles,
        h("div", { "class": "row" }, h("button", { type: "button", "class": "btn secondary", id: "spell-clear", onclick: reset }, "Effacer")));
      shell(g, st.i, list.length, body);
      tilesIds.forEach(function (id, k) {
        var l = S.byId[id];
        tiles.appendChild(h("button", { type: "button", "class": "tile", "data-letter": id, "data-k": String(k), "aria-label": "Lettre " + l.nameFr, onclick: function (ev) { add(id, ev.currentTarget); } }, ar(l.char)));
      });
      function reset() {
        if (body.getAttribute("data-done")) return;
        given = [];
        slots.querySelectorAll(".slot-box").forEach(function (b) { b.textContent = ""; b.classList.remove("filled"); });
        tiles.querySelectorAll(".tile").forEach(function (b) { b.disabled = false; });
      }
      function add(id, btn) {
        if (body.getAttribute("data-done") || given.length >= w.spell.length) return;
        given.push(id);
        btn.disabled = true;
        var box = slots.children[given.length - 1];
        box.appendChild(ar(S.byId[id].char)); box.classList.add("filled");
        V.play("tap");
        if (given.length === w.spell.length) finish();
      }
      function finish() {
        body.setAttribute("data-done", "1");
        var ok = Engine.isCorrect({ type: "order", answer: w.spell }, given);
        slots.classList.add(ok ? "ok" : "ko");
        if (ok) st.correct++;
        V.play(ok ? "ok" : "ko"); if (!ok) V.buzz(80);
        V.speak(w.word, "words", w.id, null, true);
        body.querySelectorAll("button.tile, #spell-clear").forEach(function (b) { b.disabled = true; });
        var last = st.i === list.length - 1;
        V.showSheet(ok, ok ? "Bien écrit !" : "Presque !",
          ok ? [w.translit + " veut dire « " + w.fr + " »."] : ["Les lettres dans l'ordre : " + w.spell.map(function (id) { return S.byId[id].nameFr; }).join(", ") + "."],
          last ? "Voir mon résultat" : "Mot suivant",
          function () { if (last) V.finishGame("spell", g.title, st.correct, list.length, g.pass); else { st.i++; round(); } },
          h("p", { "class": "solution" }, ar(w.word)));
      }
    }
    round();
  }

  var PLAY = { images: playImages, memory: playMemory, trace: playTrace, spell: playSpell };
  window.VDCGames = {
    GAMES: GAMES,
    menu: menu,
    play: function (id) {
      if (!PLAY[id]) { window.location.hash = "#/jeux"; return; }
      PLAY[id]();
    }
  };
  function plural(n, one, many) { return V.plural(n, one, many); }
})();
