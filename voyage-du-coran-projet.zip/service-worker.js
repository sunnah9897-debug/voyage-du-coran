/*
 * Service worker : met le jeu en cache pour qu'il s'ouvre sans Internet.
 *
 * IMPORTANT : à chaque modification d'un fichier du jeu, augmente le numéro
 * de CACHE_VERSION (v1 → v2…). Sinon les téléphones garderont l'ancienne version.
 * Tout nouveau fichier doit aussi être ajouté à la liste FILES.
 */
var CACHE_VERSION = "vdc-v0.3.0";
var FILES = [
  "./",
  "index.html",
  "css/style.css",
  "js/engine.js",
  "js/app.js",
  "js/games.js",
  "content/arabic-letters.json",
  "content/exercises.json",
  "content/words.json",
  "content/audio.json",
  "manifest.webmanifest",
  "assets/icons/icon.svg",
  "assets/icons/icon-192.png",
  "assets/icons/icon-512.png",
  "assets/fonts/lexend-latin-400-normal.woff2",
  "assets/fonts/lexend-latin-600-normal.woff2",
  "assets/fonts/lexend-latin-700-normal.woff2",
  "assets/fonts/baloo-bhaijaan-2-latin-800-normal.woff2",
  "assets/fonts/baloo-bhaijaan-2-arabic-800-normal.woff2",
  "assets/fonts/noto-naskh-arabic-arabic-400-normal.woff2",
  "assets/fonts/noto-naskh-arabic-arabic-700-normal.woff2"
];

// Installation : on télécharge tous les fichiers. Si un seul manque, l'installation échoue
// (mieux vaut échouer clairement que fonctionner à moitié hors ligne).
self.addEventListener("install", function (event) {
  event.waitUntil(
    caches.open(CACHE_VERSION)
      .then(function (cache) { return cache.addAll(FILES); })
      .then(function () { return self.skipWaiting(); })
  );
});

// Activation : on supprime les anciennes versions du cache.
self.addEventListener("activate", function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (k) { return k !== CACHE_VERSION; })
        .map(function (k) { return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

// Requêtes : d'abord le cache (rapide, marche hors ligne), sinon le réseau.
self.addEventListener("fetch", function (event) {
  var req = event.request;
  if (req.method !== "GET" || new URL(req.url).origin !== self.location.origin) return;
  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then(function (cached) {
      if (cached) return cached;
      return fetch(req).then(function (res) {
        // Les fichiers chargés plus tard (ex. enregistrements audio) sont gardés pour le hors ligne.
        if (res && res.ok && /\/content\/audio\//.test(new URL(req.url).pathname)) {
          var copy = res.clone();
          caches.open(CACHE_VERSION).then(function (c) { c.put(req, copy); });
        }
        return res;
      }).catch(function () {
        // Hors ligne et page inconnue : on renvoie l'accueil.
        if (req.mode === "navigate") return caches.match("index.html");
        return Response.error();
      });
    })
  );
});
